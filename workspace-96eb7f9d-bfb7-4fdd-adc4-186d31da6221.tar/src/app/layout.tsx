import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "RasUwa FloodLens | Rapid Flood Mapping & Impact Assessment",
  description:
    "Real-time-style disaster-response dashboard for rapid flood mapping in Rasuwa District, Nepal using Sentinel-1 SAR change detection.",
  keywords: [
    "RasUwa FloodLens",
    "flood mapping",
    "Sentinel-1",
    "SAR",
    "Google Earth Engine",
    "Nepal",
    "disaster response",
  ],
  authors: [{ name: "RasUwa FloodLens" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "RasUwa FloodLens",
    description: "Rapid Flood Mapping & Impact Assessment - Rasuwa District, Nepal",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
