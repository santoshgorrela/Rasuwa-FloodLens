"use client";

import { useState } from "react";
import { Menu } from "lucide-react";
import { Header } from "@/components/floodlens/header";
import { Sidebar, type ViewId } from "@/components/floodlens/sidebar";
import { DashboardView } from "@/components/floodlens/views/dashboard-view";
import { FloodAnalysisView } from "@/components/floodlens/views/flood-analysis-view";
import { SatelliteDataView } from "@/components/floodlens/views/satellite-data-view";
import { ImpactAssessmentView } from "@/components/floodlens/views/impact-assessment-view";
import { ReportsView } from "@/components/floodlens/views/reports-view";
import { AboutView } from "@/components/floodlens/views/about-view";
import { Toaster as SonnerToaster } from "sonner";

export default function Home() {
  const [activeView, setActiveView] = useState<ViewId>("dashboard");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  return (
    <div className="flex h-screen flex-col bg-background overflow-hidden">
      {/* Sonner toaster for notifications */}
      <SonnerToaster
        position="top-right"
        toastOptions={{
          style: {
            borderRadius: "10px",
            border: "1px solid #e2e8e0",
            fontSize: "13px",
          },
        }}
      />

      {/* Top dark-green header */}
      <Header />

      {/* Mobile nav trigger (when sidebar hidden) */}
      <div className="md:hidden flex items-center justify-between gap-3 px-4 py-2 bg-white border-b border-[#e2e8e0]">
        <button
          onClick={() => setMobileNavOpen(true)}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md text-[#0B4F3A] hover:bg-[#f4f7f5]"
        >
          <Menu className="h-4 w-4" />
          <span className="text-sm font-medium">Navigation</span>
        </button>
        <span className="text-xs text-[#6b7280] capitalize">
          {activeView.replace("-", " ")}
        </span>
      </div>

      {/* Main layout: sidebar + content */}
      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          active={activeView}
          onNavigate={setActiveView}
          mobileOpen={mobileNavOpen}
          onCloseMobile={() => setMobileNavOpen(false)}
        />

        {/* Main content */}
        <main className="flex-1 overflow-hidden bg-background">
          {activeView === "dashboard" && <DashboardView />}
          {activeView === "flood-analysis" && <FloodAnalysisView />}
          {activeView === "satellite-data" && <SatelliteDataView />}
          {activeView === "impact-assessment" && <ImpactAssessmentView />}
          {activeView === "reports" && <ReportsView />}
          {activeView === "about" && <AboutView />}
        </main>
      </div>

      {/* Footer - sticky bottom */}
      <footer className="shrink-0 border-t border-[#e2e8e0] bg-white px-4 py-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 text-[11px] text-[#9ca3af]">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-[#0B4F3A]">RasUwa FloodLens</span>
          <span className="opacity-40">|</span>
          <span>Rapid Flood Mapping &amp; Impact Assessment</span>
        </div>
        <div className="flex items-center gap-3">
          <span>Sentinel-1 SAR &middot; GEE pipeline</span>
          <span className="opacity-40">|</span>
          <span>Rasuwa, Nepal</span>
        </div>
      </footer>
    </div>
  );
}
