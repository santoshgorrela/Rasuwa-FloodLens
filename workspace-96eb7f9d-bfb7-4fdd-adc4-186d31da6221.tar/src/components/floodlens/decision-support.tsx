"use client";

import { CheckCircle2, Info, ShieldAlert, CircleDashed, Activity } from "lucide-react";
import { floodData } from "@/lib/flood-data";
import { ModelledBadge } from "./modelled-badge";

const summaryBullets = [
  {
    text:
      "RasUwa FloodLens detected a statistically significant Sentinel-1 SAR change following the 26 August 2026 Rasuwa flood event.",
    tone: "primary",
  },
  {
    text:
      "The current clean statistical flood candidate covers approximately 0.2545 hectares.",
    tone: "neutral",
  },
  {
    text:
      "Vegetation and bare/sparse surfaces account for the main detected land-cover exposure.",
    tone: "neutral",
  },
  {
    text:
      "Prototype impact estimates indicate moderate potential exposure to infrastructure and population.",
    tone: "warning",
  },
] as const;

const toneStyles: Record<string, { bg: string; fg: string; icon: typeof Info }> = {
  primary: { bg: "#E6F0EB", fg: "#0B4F3A", icon: Info },
  neutral: { bg: "#F3F4F6", fg: "#374151", icon: CircleDashed },
  positive: { bg: "#DCFCE7", fg: "#166534", icon: CheckCircle2 },
  warning: { bg: "#FEF3C7", fg: "#92400E", icon: ShieldAlert },
};

export function DecisionSupport() {
  return (
    <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
      <div
        className="px-4 py-3 border-b border-[#e2e8e0] flex items-center justify-between"
        style={{ background: "linear-gradient(90deg, #0B4F3A 0%, #1B7A5A 100%)" }}
      >
        <div className="flex items-center gap-2">
          <ShieldAlert className="h-4 w-4 text-cyan-300" />
          <h3 className="text-sm font-semibold text-white">RAPID RESPONSE SUMMARY</h3>
        </div>
        <ModelledBadge size="sm" />
      </div>

      <div className="p-4 space-y-2">
        {summaryBullets.map((b, i) => {
          const t = toneStyles[b.tone];
          const Icon = t.icon;
          return (
            <div
              key={i}
              className="flex items-start gap-2 rounded-lg p-2.5"
              style={{ background: t.bg }}
            >
              <Icon className="h-4 w-4 shrink-0 mt-0.5" style={{ color: t.fg }} />
              <p className="text-xs leading-relaxed" style={{ color: t.fg }}>
                {b.text}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

interface StatusRow {
  label: string;
  value: string;
  status: "available" | "modelled" | "none" | "info";
}

const statusRows: StatusRow[] = [
  { label: "Sentinel-1", value: "AVAILABLE", status: "available" },
  { label: "Flood Detection", value: "AVAILABLE", status: "available" },
  { label: "Land Cover", value: "AVAILABLE", status: "available" },
  { label: "Infrastructure", value: "MODELLED ESTIMATE", status: "modelled" },
  { label: "Population", value: "MODELLED ESTIMATE", status: "modelled" },
  { label: "Validation", value: "NOT FIELD-VALIDATED", status: "info" },
];

const statusBadgeStyles: Record<StatusRow["status"], { bg: string; fg: string; dot: string }> = {
  available: { bg: "#DCFCE7", fg: "#166534", dot: "#16A34A" },
  modelled: { bg: "#FEF3C7", fg: "#92400E", dot: "#D97706" },
  none: { bg: "#E0F2FE", fg: "#075985", dot: "#0EA5E9" },
  info: { bg: "#F3F4F6", fg: "#4B5563", dot: "#9CA3AF" },
};

export function DataStatus() {
  return (
    <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
      <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4 text-[#0B4F3A]" />
          <h3 className="text-sm font-semibold text-[#0f172a]">Data Status</h3>
        </div>
        <span className="text-[10px] uppercase tracking-wide text-[#9ca3af] font-medium">
          Transparency
        </span>
      </div>

      <div className="p-3 space-y-1.5">
        {statusRows.map((row) => {
          const s = statusBadgeStyles[row.status];
          return (
            <div
              key={row.label}
              className="flex items-center justify-between gap-3 py-1.5 border-b border-[#f1f5f3] last:border-0"
            >
              <span className="text-xs text-[#6b7280] font-medium">{row.label}</span>
              <span
                className="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-semibold"
                style={{ background: s.bg, color: s.fg }}
              >
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: s.dot }} />
                {row.value}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
