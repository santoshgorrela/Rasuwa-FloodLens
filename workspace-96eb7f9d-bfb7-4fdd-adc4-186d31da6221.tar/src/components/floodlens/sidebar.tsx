"use client";

import {
  LayoutDashboard,
  Waves,
  Satellite,
  AlertTriangle,
  FileText,
  Info,
  Radar,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { earthEngineLayer } from "@/lib/flood-data";

export type ViewId =
  | "dashboard"
  | "flood-analysis"
  | "satellite-data"
  | "impact-assessment"
  | "reports"
  | "about";

interface SidebarProps {
  active: ViewId;
  onNavigate: (view: ViewId) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

const navItems: { id: ViewId; label: string; icon: typeof LayoutDashboard; description: string }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, description: "Overview map & KPIs" },
  { id: "flood-analysis", label: "Flood Analysis", icon: Waves, description: "Detection methodology" },
  { id: "satellite-data", label: "Satellite Data", icon: Satellite, description: "Sentinel-1 scenes" },
  { id: "impact-assessment", label: "Impact Assessment", icon: AlertTriangle, description: "Exposure by class" },
  { id: "reports", label: "Reports", icon: FileText, description: "Generate report" },
  { id: "about", label: "About / GEE", icon: Info, description: "Workflow & Earth Engine" },
];

export function Sidebar({ active, onNavigate, mobileOpen, onCloseMobile }: SidebarProps) {
  return (
    <>
      {/* Mobile backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/40 md:hidden"
          aria-hidden="true"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={cn(
          "fixed md:static z-40 top-0 left-0 h-full md:h-auto w-64 shrink-0 bg-white border-r border-[#e2e8e0] flex flex-col transition-transform duration-200",
          mobileOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        )}
      >
        {/* Mobile close */}
        <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-[#e2e8e0]">
          <span className="text-sm font-semibold text-[#0B4F3A]">Navigation</span>
          <button
            onClick={onCloseMobile}
            className="p-1.5 rounded-md hover:bg-[#f1f5f3] text-[#0B4F3A]"
            aria-label="Close navigation"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="px-4 pt-5 pb-2">
          <p className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#6b7280]">
            Navigation
          </p>
        </div>

        <nav className="flex-1 px-3 space-y-0.5 overflow-y-auto fl-scroll">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = item.id === active;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  onCloseMobile();
                }}
                className={cn(
                  "group w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-colors",
                  isActive
                    ? "bg-[#E6F0EB] text-[#0B4F3A]"
                    : "text-[#374151] hover:bg-[#f4f7f5]"
                )}
                aria-current={isActive ? "page" : undefined}
              >
                <span
                  className={cn(
                    "flex h-8 w-8 shrink-0 items-center justify-center rounded-md transition-colors",
                    isActive
                      ? "bg-[#0B4F3A] text-white"
                      : "bg-[#f1f5f3] text-[#0B4F3A] group-hover:bg-[#e6f0eb]"
                  )}
                >
                  <Icon className="h-4 w-4" />
                </span>
                <span className="min-w-0">
                  <span className="block text-sm font-medium leading-tight">{item.label}</span>
                  <span className="block text-[11px] text-[#9ca3af] leading-tight mt-0.5 truncate">
                    {item.description}
                  </span>
                </span>
              </button>
            );
          })}
        </nav>

        {/* Footer status */}
        <div className="mt-auto px-4 py-4 border-t border-[#e2e8e0] space-y-2">
          <div className="flex items-start gap-2 text-[11px] text-[#6b7280]">
            <Radar className="h-3.5 w-3.5 mt-0.5 text-[#0B4F3A] shrink-0" />
            <div>
              <p className="font-medium text-[#374151]">Google Earth Engine</p>
              <p className="mt-0.5">
                {earthEngineLayer.connected
                  ? "Sentinel-1 GRD pipeline connected"
                  : "Sentinel-1 GRD pipeline (preview)"}
              </p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
