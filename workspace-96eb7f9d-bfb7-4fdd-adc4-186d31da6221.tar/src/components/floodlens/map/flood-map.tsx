"use client";

import { useEffect, useRef, useState } from "react";
import {
  MapContainer,
  TileLayer,
  Rectangle,
  CircleMarker,
  Polyline,
  Popup,
  ScaleControl,
  ZoomControl,
  LayerGroup,
  Tooltip as LeafletTooltip,
  useMap,
} from "react-leaflet";
import L from "leaflet";
import { Eye, Layers, Info, Crosshair, Maximize2 } from "lucide-react";
import {
  floodData,
  mapLayers,
  legendItems,
  earthEngineLayer,
} from "@/lib/flood-data";

// Map base layers
const baseLayers = [
  {
    id: "satellite",
    name: "Satellite Imagery",
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    attribution: "Esri, Maxar, Earthstar Geographics",
    maxZoom: 19,
  },
  {
    id: "standard",
    name: "Standard Map",
    url: "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",
    attribution: "&copy; OpenStreetMap &copy; CARTO",
    maxZoom: 20,
  },
  {
    id: "terrain",
    name: "Terrain",
    url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
    attribution: "&copy; OpenStreetMap, SRTM | &copy; OpenTopoMap",
    maxZoom: 17,
  },
];

const aoiBounds: L.LatLngBoundsExpression = [
  floodData.aoi.southWest,
  floodData.aoi.northEast,
];

// Approximate location of detected flood (center of AOI - represents
// where GEE detected the statistically significant change cluster).
// NOTE: This is an Analysis Preview marker. The actual flood raster
// coordinates will come from the Earth Engine export when connected.
const floodPreviewCenter: [number, number] = [28.165, 85.295];

// Modelled infrastructure point coordinates around the flood preview center.
// These are illustrative prototype positions, not field-validated features.
const buildingPoints: [number, number][] = [
  [28.168, 85.293], [28.167, 85.296], [28.169, 85.295], [28.166, 85.298],
  [28.170, 85.294], [28.164, 85.292], [28.163, 85.297], [28.171, 85.300],
  [28.162, 85.294], [28.172, 85.292], [28.165, 85.301], [28.168, 85.290],
  [28.160, 85.298], [28.173, 85.296], [28.166, 85.288], [28.159, 85.293],
  [28.174, 85.299], [28.161, 85.290],
];

const bridgePoints: [number, number][] = [
  [28.162, 85.292],
  [28.169, 85.299],
];

// Modelled road segments (Polyline) crossing the flood area
const roadSegments: [number, number][][] = [
  [[28.158, 85.285], [28.165, 85.293], [28.170, 85.299], [28.176, 85.305]],
  [[28.160, 85.300], [28.167, 85.295], [28.172, 85.290]],
];

// Population exposure circles (modelled heatmap)
const populationCircles: { center: [number, number]; radius: number; intensity: number }[] = [
  { center: [28.166, 85.295], radius: 220, intensity: 0.45 },
  { center: [28.169, 85.298], radius: 160, intensity: 0.35 },
  { center: [28.163, 85.292], radius: 180, intensity: 0.30 },
  { center: [28.171, 85.300], radius: 140, intensity: 0.28 },
];

interface LayerToggle {
  id: string;
  name: string;
  color: string;
  visible: boolean;
  isPrimary?: boolean;
  isModelled?: boolean;
}

const initialLayers: LayerToggle[] = mapLayers.map((l) => ({
  id: l.id,
  name: l.name,
  color: l.color,
  visible: l.isPrimary === true,
  isPrimary: l.isPrimary === true,
  isModelled: l.isModelled === true,
}));

function MapResizeHandler() {
  const map = useMap();
  useEffect(() => {
    const handleResize = () => {
      map.invalidateSize();
    };
    const t = setTimeout(handleResize, 200);
    window.addEventListener("resize", handleResize);
    return () => {
      clearTimeout(t);
      window.removeEventListener("resize", handleResize);
    };
  }, [map]);
  return null;
}

interface FloodMapProps {
  className?: string;
}

export function FloodMap({ className }: FloodMapProps) {
  const [activeBase, setActiveBase] = useState("satellite");
  const [layers, setLayers] = useState<LayerToggle[]>(initialLayers);
  const [showLegend, setShowLegend] = useState(true);
  const [showLayersPanel, setShowLayersPanel] = useState(true);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const activeBaseLayer = baseLayers.find((b) => b.id === activeBase) ?? baseLayers[0];

  const toggleLayer = (id: string) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === id ? { ...l, visible: !l.visible } : l))
    );
  };

  const isLayerVisible = (id: string) => layers.find((l) => l.id === id)?.visible ?? false;

  const handleFullscreen = () => {
    const el = containerRef.current as HTMLElement & { webkitRequestFullscreen?: () => void } | null;
    if (!el) return;
    if (document.fullscreenElement) {
      document.exitFullscreen?.();
    } else if (el.requestFullscreen) {
      el.requestFullscreen();
    } else if (el.webkitRequestFullscreen) {
      el.webkitRequestFullscreen();
    }
  };

  return (
    <div ref={containerRef} className={`relative h-full w-full ${className ?? ""}`}>
      <MapContainer
        center={floodData.aoi.center}
        zoom={12}
        minZoom={7}
        maxZoom={activeBaseLayer.maxZoom}
        scrollWheelZoom
        zoomControl={false}
        className="h-full w-full rounded-xl"
        style={{ background: "#eef2f0" }}
      >
        <ZoomControl position="topleft" />
        <ScaleControl position="bottomleft" imperial={false} />

        <MapResizeHandler />

        {/* Active base layer (state-driven) */}
        <TileLayer
          key={activeBaseLayer.id}
          url={activeBaseLayer.url}
          attribution={activeBaseLayer.attribution}
          maxZoom={activeBaseLayer.maxZoom}
        />

        {/* AOI rectangle - Rasuwa study area */}
        <Rectangle
          bounds={aoiBounds}
          pathOptions={{
            color: "#0B4F3A",
            weight: 2,
            fillColor: "#0B4F3A",
            fillOpacity: 0.04,
            dashArray: "6 4",
          }}
        >
          <LeafletTooltip sticky>
            Rasuwa Study AOI &middot; ~1,725 km&sup2;
          </LeafletTooltip>
        </Rectangle>

        {/* Flood extent preview (Analysis Preview marker) */}
        {isLayerVisible("flood-extent") && (
          <LayerGroup>
            <CircleMarker
              center={floodPreviewCenter}
              radius={16}
              pathOptions={{
                color: "#06B6D4",
                weight: 2,
                fillColor: "#06B6D4",
                fillOpacity: 0.55,
              }}
            >
              <Popup>
                <div className="text-xs space-y-1">
                  <div className="font-semibold text-[#0B4F3A]">Final Flood Extent</div>
                  <div>Area: {floodData.floodAreaM2Display}</div>
                  <div>({floodData.floodAreaHaDisplay})</div>
                  <div className="text-[#6b7280] mt-1">
                    {earthEngineLayer.label} &middot; Sentinel-1 SAR change detection
                  </div>
                </div>
              </Popup>
            </CircleMarker>
            <CircleMarker
              center={floodPreviewCenter}
              radius={4}
              pathOptions={{ color: "#0E7490", fillColor: "#0E7490", fillOpacity: 1, weight: 1 }}
            />
          </LayerGroup>
        )}

        {/* Pre-event SAR preview marker */}
        {isLayerVisible("pre-sar") && (
          <CircleMarker
            center={[28.115, 85.235]}
            radius={9}
            pathOptions={{ color: "#4B5563", fillColor: "#4B5563", fillOpacity: 0.45, weight: 1.5 }}
          >
            <Popup>
              <div className="text-xs">
                <div className="font-semibold text-[#0B4F3A]">Pre-event Sentinel-1</div>
                <div>{floodData.preDateDisplay}</div>
                <div className="text-[#6b7280] mt-1">{earthEngineLayer.label}</div>
              </div>
            </Popup>
          </CircleMarker>
        )}

        {/* Post-event SAR preview marker */}
        {isLayerVisible("post-sar") && (
          <CircleMarker
            center={[28.205, 85.345]}
            radius={9}
            pathOptions={{ color: "#1F2937", fillColor: "#1F2937", fillOpacity: 0.5, weight: 1.5 }}
          >
            <Popup>
              <div className="text-xs">
                <div className="font-semibold text-[#0B4F3A]">Post-event Sentinel-1</div>
                <div>{floodData.postDateDisplay}</div>
                <div className="text-[#6b7280] mt-1">{earthEngineLayer.label}</div>
              </div>
            </Popup>
          </CircleMarker>
        )}

        {/* Flooded vegetation */}
        {isLayerVisible("flooded-veg") && (
          <CircleMarker
            center={[28.18, 85.28]}
            radius={6}
            pathOptions={{ color: "#16A34A", fillColor: "#16A34A", fillOpacity: 0.6, weight: 1 }}
          >
            <Popup>
              <div className="text-xs">
                <div className="font-semibold text-[#16A34A]">Flooded Vegetation</div>
                <div>{floodData.vegetationDisplay}</div>
              </div>
            </Popup>
          </CircleMarker>
        )}

        {/* Flooded bare/sparse land */}
        {isLayerVisible("flooded-bare") && (
          <CircleMarker
            center={[28.155, 85.31]}
            radius={6}
            pathOptions={{ color: "#D97706", fillColor: "#D97706", fillOpacity: 0.6, weight: 1 }}
          >
            <Popup>
              <div className="text-xs">
                <div className="font-semibold text-[#D97706]">Flooded Bare/Sparse Land</div>
                <div>{floodData.bareLandDisplay}</div>
              </div>
            </Popup>
          </CircleMarker>
        )}

        {/* Flooded cropland (no exposure detected) */}
        {isLayerVisible("flooded-crop") && (
          <CircleMarker
            center={[28.135, 85.265]}
            radius={5}
            pathOptions={{ color: "#CA8A04", fillColor: "#CA8A04", fillOpacity: 0.35, weight: 1, dashArray: "3 2" }}
          >
            <Popup>
              <div className="text-xs">
                <div className="font-semibold text-[#CA8A04]">Flooded Cropland</div>
                <div>0 m&sup2; detected in current layer</div>
              </div>
            </Popup>
          </CircleMarker>
        )}

        {/* Flooded built-up (no exposure detected) */}
        {isLayerVisible("flooded-built") && (
          <CircleMarker
            center={[28.195, 85.32]}
            radius={5}
            pathOptions={{ color: "#B91C1C", fillColor: "#B91C1C", fillOpacity: 0.35, weight: 1, dashArray: "3 2" }}
          >
            <Popup>
              <div className="text-xs">
                <div className="font-semibold text-[#B91C1C]">Flooded Built-up</div>
                <div>0 m&sup2; detected in current layer</div>
              </div>
            </Popup>
          </CircleMarker>
        )}

        {/* MODELLED: Affected Roads (Polyline) */}
        {isLayerVisible("affected-roads") && (
          <LayerGroup>
            {roadSegments.map((seg, idx) => (
              <Polyline
                key={`road-${idx}`}
                positions={seg}
                pathOptions={{ color: "#F97316", weight: 4, opacity: 0.85 }}
              >
                <Popup>
                  <div className="text-xs">
                    <div className="font-semibold text-[#F97316]">Affected Road Segment</div>
                    <div>Length: {(floodData.modelledImpact.affectedRoadKm / roadSegments.length).toFixed(2)} km (segment)</div>
                    <div className="text-[#6b7280] mt-1">Modelled estimate</div>
                  </div>
                </Popup>
              </Polyline>
            ))}
          </LayerGroup>
        )}

        {/* MODELLED: Affected Buildings (multiple markers) */}
        {isLayerVisible("affected-buildings") && (
          <LayerGroup>
            {buildingPoints.map((pt, idx) => (
              <CircleMarker
                key={`bld-${idx}`}
                center={pt}
                radius={3.5}
                pathOptions={{ color: "#DC2626", fillColor: "#DC2626", fillOpacity: 0.85, weight: 1 }}
              >
                {idx === 0 && (
                  <Popup>
                    <div className="text-xs">
                      <div className="font-semibold text-[#DC2626]">Affected Buildings</div>
                      <div>{floodData.modelledImpact.affectedBuildings} building footprints</div>
                      <div className="text-[#6b7280] mt-1">Modelled estimate</div>
                    </div>
                  </Popup>
                )}
              </CircleMarker>
            ))}
          </LayerGroup>
        )}

        {/* MODELLED: Affected Bridges (point markers) */}
        {isLayerVisible("affected-bridges") && (
          <LayerGroup>
            {bridgePoints.map((pt, idx) => (
              <CircleMarker
                key={`brg-${idx}`}
                center={pt}
                radius={7}
                pathOptions={{
                  color: "#9333EA",
                  weight: 2,
                  fillColor: "#9333EA",
                  fillOpacity: 0.75,
                }}
              >
                <Popup>
                  <div className="text-xs">
                    <div className="font-semibold text-[#9333EA]">Affected Bridge</div>
                    <div>Bridge #{idx + 1} of {floodData.modelledImpact.affectedBridges}</div>
                    <div className="text-[#6b7280] mt-1">Modelled estimate</div>
                  </div>
                </Popup>
              </CircleMarker>
            ))}
          </LayerGroup>
        )}

        {/* MODELLED: Population Exposure (heatmap-style circles) */}
        {isLayerVisible("population-exposure") && (
          <LayerGroup>
            {populationCircles.map((c, idx) => (
              <CircleMarker
                key={`pop-${idx}`}
                center={c.center}
                radius={Math.max(c.radius / 8, 14)}
                pathOptions={{
                  color: "#0EA5E9",
                  weight: 1,
                  fillColor: "#0EA5E9",
                  fillOpacity: c.intensity,
                }}
              >
                {idx === 0 && (
                  <Popup>
                    <div className="text-xs">
                      <div className="font-semibold text-[#0284C7]">Population Exposure</div>
                      <div>Estimated: {floodData.modelledImpact.populationExposure} people</div>
                      <div className="text-[#6b7280] mt-1">Modelled estimate</div>
                    </div>
                  </Popup>
                )}
              </CircleMarker>
            ))}
          </LayerGroup>
        )}
      </MapContainer>

      {/* Analysis Preview badge (top-center) */}
      <div className="absolute top-3 left-1/2 -translate-x-1/2 z-[1000] pointer-events-none">
        <div className="map-overlay-panel px-3 py-1.5 inline-flex items-center gap-2 pointer-events-auto">
          <Info className="h-3.5 w-3.5 text-[#0B4F3A]" />
          <span className="text-[11px] font-medium text-[#374151]">
            {earthEngineLayer.label}
          </span>
          <span className="text-[10px] text-[#9ca3af]">&middot; Sentinel-1 SAR change detection</span>
        </div>
      </div>

      {/* Layers & Opacity panel */}
      <div className="absolute bottom-4 left-4 z-[1000] max-w-[260px]">
        <div className="map-overlay-panel overflow-hidden">
          <button
            onClick={() => setShowLayersPanel((s) => !s)}
            className="w-full flex items-center justify-between gap-2 px-3 py-2 hover:bg-[#f4f7f5] transition-colors"
          >
            <span className="flex items-center gap-2 text-xs font-semibold text-[#0B4F3A]">
              <Layers className="h-3.5 w-3.5" />
              Layers &amp; Opacity
            </span>
            <span className="text-[10px] text-[#9ca3af]">{showLayersPanel ? "▾" : "▸"}</span>
          </button>
          {showLayersPanel && (
            <div className="px-3 pb-3 pt-1 space-y-1.5 max-h-[320px] overflow-y-auto fl-scroll">
              {layers.map((layer) => (
                <label
                  key={layer.id}
                  className="flex items-center gap-2 cursor-pointer group py-0.5"
                >
                  <button
                    onClick={() => toggleLayer(layer.id)}
                    className="relative inline-flex h-4 w-7 shrink-0 items-center rounded-full transition-colors"
                    style={{
                      background: layer.visible ? layer.color : "#d1d5db",
                    }}
                    role="switch"
                    aria-checked={layer.visible}
                    aria-label={`Toggle ${layer.name}`}
                  >
                    <span
                      className={`inline-block h-3 w-3 transform rounded-full bg-white shadow transition-transform ${
                        layer.visible ? "translate-x-3.5" : "translate-x-0.5"
                      }`}
                    />
                  </button>
                  <span
                    className="h-2.5 w-2.5 rounded-sm shrink-0"
                    style={{ background: layer.color }}
                  />
                  <span className="text-[11px] text-[#374151] leading-tight flex-1">
                    {layer.name}
                    {layer.isPrimary && (
                      <span className="ml-1 text-[9px] uppercase tracking-wide text-[#0B4F3A] font-semibold">
                        primary
                      </span>
                    )}
                    {layer.isModelled && (
                      <span className="ml-1 text-[9px] uppercase tracking-wide text-[#92400E] font-semibold">
                        modelled
                      </span>
                    )}
                  </span>
                </label>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Base layer switcher (top-right) */}
      <div className="absolute top-3 right-3 z-[1000] flex gap-1">
        <div className="map-overlay-panel p-1 flex gap-0.5">
          {baseLayers.map((bl) => (
            <button
              key={bl.id}
              onClick={() => setActiveBase(bl.id)}
              className={`px-2.5 py-1 text-[10px] font-medium rounded-md transition-colors ${
                activeBase === bl.id
                  ? "bg-[#0B4F3A] text-white"
                  : "text-[#374151] hover:bg-[#f4f7f5]"
              }`}
              title={bl.name}
            >
              {bl.name.split(" ")[0]}
            </button>
          ))}
        </div>
        <button
          onClick={handleFullscreen}
          className="map-overlay-panel p-1.5 text-[#0B4F3A] hover:bg-[#f4f7f5] transition-colors"
          title="Toggle fullscreen map"
          aria-label="Toggle fullscreen"
        >
          <Maximize2 className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Legend (bottom-right) */}
      <div className="absolute bottom-4 right-4 z-[1000] max-w-[220px]">
        <div className="map-overlay-panel overflow-hidden">
          <button
            onClick={() => setShowLegend((s) => !s)}
            className="w-full flex items-center justify-between gap-2 px-3 py-2 hover:bg-[#f4f7f5] transition-colors"
          >
            <span className="flex items-center gap-2 text-xs font-semibold text-[#0B4F3A]">
              <Eye className="h-3.5 w-3.5" />
              Legend
            </span>
            <span className="text-[10px] text-[#9ca3af]">{showLegend ? "▾" : "▸"}</span>
          </button>
          {showLegend && (
            <div className="px-3 pb-3 pt-1 space-y-1.5 max-h-[280px] overflow-y-auto fl-scroll">
              {legendItems.map((item) => (
                <div key={item.label} className="flex items-center gap-2">
                  <span
                    className="h-3 w-3 rounded-sm shrink-0 border border-black/5"
                    style={{ background: item.color }}
                  />
                  <span className="text-[11px] text-[#374151] leading-tight">{item.label}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Center crosshair info */}
      <div className="absolute top-3 left-3 z-[1000]">
        <div className="map-overlay-panel px-3 py-1.5 flex items-center gap-2">
          <Crosshair className="h-3.5 w-3.5 text-[#0B4F3A]" />
          <span className="text-[11px] text-[#374151]">
            Rasuwa AOI &middot; {floodData.aoi.center[0].toFixed(2)}&deg;N, {floodData.aoi.center[1].toFixed(2)}&deg;E
          </span>
        </div>
      </div>
    </div>
  );
}
