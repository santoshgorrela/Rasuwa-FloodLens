"use client";

import { Radar, Satellite, Waves, Sigma, Clock, Activity } from "lucide-react";
import { floodData } from "@/lib/flood-data";

export function FloodAnalysisPanel() {
  return (
    <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
      {/* Panel header */}
      <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center justify-between" style={{ background: "#0B4F3A" }}>
        <div className="flex items-center gap-2">
          <Waves className="h-4 w-4 text-cyan-300" />
          <h3 className="text-sm font-semibold text-white">Flood Analysis</h3>
        </div>
        <span
          className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide"
          style={{ background: "rgba(6, 182, 212, 0.18)", color: "#a5f3fc" }}
        >
          <Satellite className="h-3 w-3" />
          Sentinel-1 SAR
        </span>
      </div>

      <div className="p-4 space-y-4">
        {/* Acquisition info */}
        <div className="space-y-2">
          <p className="text-[10px] font-semibold uppercase tracking-wider text-[#9ca3af]">
            Acquisition Information
          </p>
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-[#f4f7f5] rounded-lg p-2.5">
              <p className="text-[10px] text-[#6b7280]">Pre-flood</p>
              <p className="text-sm font-semibold text-[#0B4F3A]">{floodData.preDateDisplay}</p>
            </div>
            <div className="bg-[#f4f7f5] rounded-lg p-2.5">
              <p className="text-[10px] text-[#6b7280]">Post-flood</p>
              <p className="text-sm font-semibold text-[#0B4F3A]">{floodData.postDateDisplay}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-x-3 gap-y-2 text-xs">
            <InfoRow icon={Radar} label="Orbit / Pass" value={`${floodData.orbit} / ${floodData.relativeOrbit}`} />
            <InfoRow icon={Radar} label="Polarization" value={floodData.polarizationDisplay} />
            <InfoRow icon={Activity} label="Resolution" value={`${floodData.resolution} m`} />
            <InfoRow icon={Activity} label="Mode" value={floodData.mode} />
          </div>
        </div>

        {/* Detection */}
        <div className="border-t border-[#e2e8e0] pt-3 space-y-2">
          <p className="text-[10px] font-semibold uppercase tracking-wider text-[#9ca3af]">
            Detection Method
          </p>
          <p className="text-xs text-[#374151] leading-relaxed">{floodData.detectionMethodShort}</p>
          <div className="flex items-center gap-2 text-xs">
            <Sigma className="h-3.5 w-3.5 text-[#0B4F3A]" />
            <span className="text-[#6b7280]">Threshold:</span>
            <span className="font-semibold text-[#0B4F3A]">{floodData.significanceDisplay}</span>
          </div>
        </div>

        {/* Detected flood area */}
        <div className="border-t border-[#e2e8e0] pt-3 space-y-2">
          <p className="text-[10px] font-semibold uppercase tracking-wider text-[#9ca3af]">
            Detected Flood Area
          </p>
          <div className="rounded-lg p-3" style={{ background: "#CFFAFE" }}>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-[#0E7490]" style={{ fontVariantNumeric: "tabular-nums" }}>
                {floodData.floodAreaKm2Display}
              </span>
              <span className="text-[10px] font-semibold uppercase text-[#0E7490]/70">flood extent</span>
            </div>
            <p className="text-xs text-[#0E7490]/80 mt-1">
              Equivalent: <span className="font-semibold">{floodData.floodAreaHaDisplay}</span> ({floodData.floodAreaM2Display})
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <Clock className="h-3.5 w-3.5 text-green-600" />
            <span className="text-[#374151]">{floodData.confidenceWording}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoRow({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Radar;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center gap-1.5">
      <Icon className="h-3 w-3 text-[#9ca3af] shrink-0" />
      <span className="text-[#6b7280] text-[11px]">{label}:</span>
      <span className="font-semibold text-[#374151] text-[11px] ml-auto">{value}</span>
    </div>
  );
}
