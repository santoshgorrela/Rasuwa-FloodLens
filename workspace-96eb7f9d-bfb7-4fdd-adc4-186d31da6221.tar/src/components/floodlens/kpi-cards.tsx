"use client";

import { Waves, Sigma, Calendar, ShieldAlert } from "lucide-react";
import { floodData } from "@/lib/flood-data";
import { ModelledBadge } from "./modelled-badge";

interface KpiCardProps {
  title: string;
  main: string;
  secondary: string;
  extra?: React.ReactNode;
  icon: typeof Waves;
  accent: "flood" | "detection" | "event" | "impact";
  children?: React.ReactNode;
}

const accentStyles: Record<
  KpiCardProps["accent"],
  { bg: string; fg: string; bar: string }
> = {
  flood: { bg: "#CFFAFE", fg: "#0E7490", bar: "#06B6D4" },
  detection: { bg: "#E6F0EB", fg: "#0B4F3A", bar: "#0B4F3A" },
  event: { bg: "#FEF3C7", fg: "#92400E", bar: "#D97706" },
  impact: { bg: "#FEE2E2", fg: "#991B1B", bar: "#DC2626" },
};

function KpiCard({ title, main, secondary, extra, icon: Icon, accent, children }: KpiCardProps) {
  const styles = accentStyles[accent];
  return (
    <div className="bg-white rounded-xl border border-[#e2e8e0] p-4 flex flex-col gap-3 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-[#6b7280]">
          {title}
        </span>
        <span
          className="flex h-8 w-8 items-center justify-center rounded-lg"
          style={{ background: styles.bg, color: styles.fg }}
        >
          <Icon className="h-4 w-4" />
        </span>
      </div>
      <div className="space-y-1">
        <div
          className="text-xl md:text-2xl font-bold tracking-tight text-[#0f172a] leading-none"
          style={{ fontVariantNumeric: "tabular-nums" }}
        >
          {main}
        </div>
        <div className="text-sm font-medium text-[#374151]">{secondary}</div>
        {extra && <div className="text-xs text-[#9ca3af]">{extra}</div>}
        {children}
      </div>
      <div className="mt-auto h-1 w-full rounded-full" style={{ background: styles.bar, opacity: 0.85 }} />
    </div>
  );
}

export function KpiCards() {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
      <KpiCard
        title="Flood Extent"
        main={floodData.floodAreaKm2Display}
        secondary={floodData.floodAreaHaDisplay}
        extra={floodData.floodAreaM2Display}
        icon={Waves}
        accent="flood"
      />
      <KpiCard
        title="Detection"
        main={floodData.significanceDisplay}
        secondary="Statistical SAR"
        icon={Sigma}
        accent="detection"
      />
      <KpiCard
        title="Event Date"
        main={floodData.eventDateDisplay}
        secondary={floodData.region}
        icon={Calendar}
        accent="event"
      />
      <KpiCard
        title="Impact Level"
        main={floodData.modelledImpact.impactLevel.toUpperCase()}
        secondary="Modelled estimate"
        icon={ShieldAlert}
        accent="impact"
      >
        <div className="pt-1">
          <ModelledBadge size="sm" />
        </div>
      </KpiCard>
    </div>
  );
}
