"use client";

import { Info } from "lucide-react";
import { modelledEstimateTooltip, modelledDisclaimerBanner } from "@/lib/flood-data";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface ModelledBadgeProps {
  size?: "sm" | "md";
  className?: string;
}

export function ModelledBadge({ size = "sm", className = "" }: ModelledBadgeProps) {
  const sizing =
    size === "sm"
      ? "text-[9px] px-1.5 py-0.5 gap-1"
      : "text-[10px] px-2 py-1 gap-1";
  return (
    <TooltipProvider delayDuration={200}>
      <Tooltip>
        <TooltipTrigger asChild>
          <span
            className={`inline-flex items-center rounded-full font-semibold uppercase tracking-wide ${sizing} ${className}`}
            style={{
              background: "#FEF3C7",
              color: "#92400E",
              border: "1px solid #FCD34D",
            }}
          >
            <span className="h-1 w-1 rounded-full bg-amber-500" />
            Modelled estimate
          </span>
        </TooltipTrigger>
        <TooltipContent
          side="top"
          className="max-w-[220px] text-[11px] leading-relaxed"
        >
          {modelledEstimateTooltip}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

export function ModelledDisclaimerBanner() {
  return (
    <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 flex items-start gap-2">
      <Info className="h-3.5 w-3.5 text-amber-600 shrink-0 mt-0.5" />
      <p className="text-[11px] text-amber-800 leading-relaxed">
        {modelledDisclaimerBanner}
      </p>
    </div>
  );
}
