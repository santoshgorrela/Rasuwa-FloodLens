"use client";

import {
  Waves,
  Radar,
  Satellite,
  Sigma,
  ArrowDown,
  ArrowRight,
  CircleDot,
  Layers3,
  Clock,
  CheckCircle2,
} from "lucide-react";
import { floodData, methodologyFlow } from "@/lib/flood-data";

export function FloodAnalysisView() {
  const eventInfo: { label: string; value: string }[] = [
    { label: "Event", value: `${floodData.eventDateDisplay} (26 August 2026)` },
    { label: "Pre-event", value: floodData.preDateDisplay },
    { label: "Post-event", value: floodData.postDateDisplay },
    { label: "Satellite", value: `${floodData.satellite} SAR` },
    { label: "Polarization", value: floodData.polarizationDisplay },
    { label: "Pass", value: floodData.passDirection },
    { label: "Relative Orbit", value: String(floodData.relativeOrbit) },
    { label: "Statistical threshold", value: floodData.significanceDisplay },
  ];

  return (
    <div className="overflow-y-auto fl-scroll h-full">
      <div className="p-4 md:p-6 max-w-6xl mx-auto space-y-5">
        {/* Page header */}
        <div className="flex items-center gap-3">
          <div
            className="flex h-10 w-10 items-center justify-center rounded-lg"
            style={{ background: "#0B4F3A" }}
          >
            <Waves className="h-5 w-5 text-cyan-300" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-[#0f172a]">Flood Analysis</h2>
            <p className="text-xs text-[#6b7280] mt-0.5">
              Sentinel-1 SAR statistical change detection &middot; Rasuwa, Nepal
            </p>
          </div>
        </div>

        {/* Event info grid */}
        <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
          <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center gap-2">
            <CircleDot className="h-4 w-4 text-[#0B4F3A]" />
            <h3 className="text-sm font-semibold text-[#0f172a]">Detection Parameters</h3>
          </div>
          <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {eventInfo.map((row) => (
              <div key={row.label} className="bg-[#f9fafb] rounded-lg p-3 border border-[#f1f5f3]">
                <p className="text-[10px] uppercase tracking-wide text-[#9ca3af] font-semibold">
                  {row.label}
                </p>
                <p className="text-sm font-semibold text-[#0B4F3A] mt-1" style={{ fontVariantNumeric: "tabular-nums" }}>
                  {row.value}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Final flood extent */}
        <div
          className="rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm"
          style={{ background: "linear-gradient(90deg, #CFFAFE 0%, #ffffff 60%)" }}
        >
          <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-[#0E7490]" />
            <h3 className="text-sm font-semibold text-[#0E7490]">Final Flood Extent</h3>
          </div>
          <div className="p-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-white rounded-lg p-4 border border-[#e2e8e0]">
              <p className="text-[10px] uppercase tracking-wide text-[#9ca3af] font-semibold">
                Square meters
              </p>
              <p className="text-2xl font-bold text-[#0E7490] mt-1" style={{ fontVariantNumeric: "tabular-nums" }}>
                {floodData.floodAreaM2Display}
              </p>
            </div>
            <div className="bg-white rounded-lg p-4 border border-[#e2e8e0]">
              <p className="text-[10px] uppercase tracking-wide text-[#9ca3af] font-semibold">
                Hectares
              </p>
              <p className="text-2xl font-bold text-[#0E7490] mt-1" style={{ fontVariantNumeric: "tabular-nums" }}>
                {floodData.floodAreaHaDisplay}
              </p>
            </div>
            <div className="bg-white rounded-lg p-4 border border-[#e2e8e0]">
              <p className="text-[10px] uppercase tracking-wide text-[#9ca3af] font-semibold">
                Square kilometers
              </p>
              <p className="text-2xl font-bold text-[#0E7490] mt-1" style={{ fontVariantNumeric: "tabular-nums" }}>
                {floodData.floodAreaKm2Display}
              </p>
            </div>
          </div>
          <div className="px-4 pb-3 flex items-center gap-2 text-xs text-[#0E7490]">
            <Clock className="h-3.5 w-3.5" />
            {floodData.confidenceWording} &middot; threshold {floodData.significanceDisplay}
          </div>
        </div>

        {/* Methodology flow */}
        <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
          <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center gap-2">
            <Layers3 className="h-4 w-4 text-[#0B4F3A]" />
            <h3 className="text-sm font-semibold text-[#0f172a]">Methodology Flow</h3>
          </div>
          <div className="p-4">
            <div className="space-y-2">
              {methodologyFlow.map((step, idx) => (
                <div key={step.step}>
                  <div
                    className="flex items-start gap-3 rounded-lg p-3 border border-[#e2e8e0]"
                    style={{ background: idx === methodologyFlow.length - 1 ? "#E6F0EB" : "#f9fafb" }}
                  >
                    <span
                      className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-[11px] font-bold"
                      style={{
                        background: idx === methodologyFlow.length - 1 ? "#0B4F3A" : "#0B4F3A22",
                        color: idx === methodologyFlow.length - 1 ? "#ffffff" : "#0B4F3A",
                      }}
                    >
                      {step.step}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-[#0f172a]">{step.label}</p>
                      <p className="text-xs text-[#6b7280] mt-0.5">{step.description}</p>
                    </div>
                    {idx === methodologyFlow.length - 1 && (
                      <CheckCircle2 className="h-4 w-4 text-[#0B4F3A] shrink-0 mt-0.5" />
                    )}
                  </div>
                  {idx < methodologyFlow.length - 1 && (
                    <div className="flex justify-center py-1">
                      <ArrowDown className="h-4 w-4 text-[#9ca3af]" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Acquisition metadata */}
        <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
          <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center gap-2">
            <Satellite className="h-4 w-4 text-[#0B4F3A]" />
            <h3 className="text-sm font-semibold text-[#0f172a]">Acquisition Summary</h3>
          </div>
          <div className="p-4 grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            <InfoCell label="Mode" value={floodData.mode} />
            <InfoCell label="Resolution" value={`${floodData.resolution} m`} />
            <InfoCell label="Effective looks" value={String(floodData.effectiveLooks)} />
            <InfoCell label="Pass direction" value={floodData.passDirection} />
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoCell({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-[#f9fafb] rounded-lg p-3 border border-[#f1f5f3]">
      <p className="text-[10px] uppercase tracking-wide text-[#9ca3af] font-semibold">{label}</p>
      <p className="text-sm font-semibold text-[#374151] mt-1">{value}</p>
    </div>
  );
}
