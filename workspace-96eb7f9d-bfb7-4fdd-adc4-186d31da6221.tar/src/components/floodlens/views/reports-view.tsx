"use client";

import { useState } from "react";
import {
  FileText,
  Download,
  Calendar,
  Satellite,
  Waves,
  Layers3,
  AlertTriangle,
  Settings2,
  ShieldAlert,
  Printer,
  CheckCircle2,
  Info,
  Route,
  Users,
  Wheat,
  Gauge,
  Database,
} from "lucide-react";
import {
  floodData,
  methodologyFlow,
  earthEngineLayer,
} from "@/lib/flood-data";
import { toast } from "sonner";
import { ModelledBadge, ModelledDisclaimerBanner } from "../modelled-badge";

export function ReportsView() {
  const [generating, setGenerating] = useState(false);

  const handleGenerate = () => {
    setGenerating(true);
    toast.info("Generating report...", {
      description: "Preparing print-friendly view.",
    });
    setTimeout(() => {
      setGenerating(false);
      toast.success("Report ready", {
        description: "Use your browser's print dialog to save as PDF.",
      });
      if (typeof window !== "undefined") {
        window.print();
      }
    }, 600);
  };

  const handlePrint = () => {
    if (typeof window !== "undefined") {
      window.print();
    }
  };

  const handleExportCsv = () => {
    try {
      const rows: { key: string; label: string; value: string; tier: string }[] = [
        { key: "event_date", label: "Event date", value: floodData.eventDateDisplay, tier: "detected" },
        { key: "pre_event_date", label: "Pre-event acquisition", value: floodData.preDateDisplay, tier: "detected" },
        { key: "post_event_date", label: "Post-event acquisition", value: floodData.postDateDisplay, tier: "detected" },
        { key: "location", label: "Location", value: floodData.location, tier: "detected" },
        { key: "satellite", label: "Satellite", value: floodData.satellite, tier: "detected" },
        { key: "mode", label: "Mode", value: floodData.mode, tier: "detected" },
        { key: "pass", label: "Pass direction", value: floodData.passDirection, tier: "detected" },
        { key: "relative_orbit", label: "Relative orbit", value: String(floodData.relativeOrbit), tier: "detected" },
        { key: "polarization", label: "Polarization", value: floodData.polarizationDisplay, tier: "detected" },
        { key: "resolution_m", label: "Resolution (m)", value: String(floodData.resolution), tier: "detected" },
        { key: "effective_looks", label: "Effective looks", value: String(floodData.effectiveLooks), tier: "detected" },
        { key: "pre_scene_id", label: "Pre-event scene ID", value: floodData.preSceneId, tier: "detected" },
        { key: "post_scene_id", label: "Post-event scene ID", value: floodData.postSceneId, tier: "detected" },
        { key: "significance", label: "Significance threshold", value: floodData.significanceDisplay, tier: "detected" },
        { key: "flood_extent_m2", label: "Flood extent (m^2)", value: floodData.floodAreaM2.toFixed(6), tier: "detected" },
        { key: "flood_extent_ha", label: "Flood extent (ha)", value: floodData.floodAreaHa.toFixed(6), tier: "detected" },
        { key: "flood_extent_km2", label: "Flood extent (km^2)", value: floodData.floodAreaKm2.toFixed(8), tier: "detected" },
        { key: "vegetation_m2", label: "Flooded vegetation (m^2)", value: floodData.vegetationM2.toFixed(4), tier: "detected" },
        { key: "bare_land_m2", label: "Flooded bare/sparse (m^2)", value: floodData.bareLandM2.toFixed(4), tier: "detected" },
        { key: "cropland_m2", label: "Flooded cropland (m^2)", value: floodData.croplandM2.toFixed(4), tier: "detected" },
        { key: "built_up_m2", label: "Flooded built-up (m^2)", value: floodData.builtUpM2.toFixed(4), tier: "detected" },
        { key: "other_m2", label: "Flooded other (m^2)", value: floodData.otherM2.toFixed(4), tier: "detected" },
        { key: "affected_road_km", label: "Affected road length (km)", value: String(floodData.modelledImpact.affectedRoadKm), tier: "modelled" },
        { key: "affected_buildings", label: "Affected buildings", value: String(floodData.modelledImpact.affectedBuildings), tier: "modelled" },
        { key: "affected_bridges", label: "Affected bridges", value: String(floodData.modelledImpact.affectedBridges), tier: "modelled" },
        { key: "population_exposure", label: "Population exposure", value: String(floodData.modelledImpact.populationExposure), tier: "modelled" },
        { key: "agriculture_ha", label: "Affected agriculture (ha)", value: String(floodData.modelledImpact.agricultureHa), tier: "modelled" },
        { key: "settlement_ha", label: "Affected settlement (ha)", value: String(floodData.modelledImpact.settlementHa), tier: "modelled" },
        { key: "impact_level", label: "Impact level", value: floodData.modelledImpact.impactLevel, tier: "modelled" },
        { key: "risk_score", label: "Rapid impact score", value: String(floodData.riskScore.total), tier: "modelled" },
        { key: "risk_classification", label: "Risk classification", value: floodData.riskScore.classification, tier: "modelled" },
      ];

      const header = "key,label,value,tier\n";
      const body = rows
        .map((r) => {
          const safeValue = `"${String(r.value).replace(/"/g, '""')}"`;
          const safeLabel = `"${r.label.replace(/"/g, '""')}"`;
          return `${r.key},${safeLabel},${safeValue},${r.tier}`;
        })
        .join("\n");

      const csv = header + body + "\n";
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `rasuwa-floodlens-report-${floodData.eventDate}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success("CSV exported", {
        description: `rasuwa-floodlens-report-${floodData.eventDate}.csv`,
      });
    } catch (err) {
      console.error("CSV export failed", err);
      toast.error("CSV export failed", {
        description: "Please try the Print Report option instead.",
      });
    }
  };

  return (
    <div className="overflow-y-auto fl-scroll h-full">
      <div className="p-4 md:p-6 max-w-5xl mx-auto space-y-5">
        {/* Page header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 print:hidden">
          <div className="flex items-center gap-3">
            <div
              className="flex h-10 w-10 items-center justify-center rounded-lg"
              style={{ background: "#0B4F3A" }}
            >
              <FileText className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-[#0f172a]">Reports</h2>
              <p className="text-xs text-[#6b7280] mt-0.5">
                Generate a printable rapid flood assessment report
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={handleGenerate}
              disabled={generating}
              className="inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold text-white shadow-sm hover:shadow-md disabled:opacity-60 transition-all"
              style={{ background: "#0B4F3A" }}
            >
              {generating ? (
                <>
                  <Settings2 className="h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Download className="h-4 w-4" />
                  Generate Report
                </>
              )}
            </button>
            <button
              onClick={handleExportCsv}
              className="inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold text-[#0B4F3A] border border-[#0B4F3A]/20 hover:bg-[#E6F0EB] transition-colors"
            >
              <Download className="h-4 w-4" />
              Export CSV
            </button>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-[#0B4F3A] border border-[#0B4F3A]/20 hover:bg-[#E6F0EB] transition-colors"
            >
              <Printer className="h-4 w-4" />
              Print Report
            </button>
          </div>
        </div>

        {/* Report document */}
        <div
          id="report-document"
          className="bg-white rounded-xl border border-[#e2e8e0] shadow-sm overflow-hidden"
        >
          {/* Report header */}
          <div
            className="px-6 py-5 text-white"
            style={{ background: "linear-gradient(90deg, #0B4F3A 0%, #1B7A5A 100%)" }}
          >
            <div className="flex items-center gap-2">
              <Waves className="h-5 w-5 text-cyan-300" />
              <h2 className="text-lg font-semibold">RasUwa FloodLens</h2>
            </div>
            <p className="text-sm text-emerald-100/90 mt-1">
              Rapid Flood Assessment Report
            </p>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-[11px] text-emerald-100/80">
              <span className="flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                Event: {floodData.eventDateDisplay}
              </span>
              <span className="flex items-center gap-1">
                <Info className="h-3 w-3" />
                Generated: {floodData.lastUpdatedDisplay}
              </span>
              <span className="flex items-center gap-1">
                <Satellite className="h-3 w-3" />
                {floodData.satellite} SAR
              </span>
            </div>
          </div>

          <div className="p-6 space-y-5 text-sm text-[#374151]">
            {/* 1. Event Summary */}
            <ReportSection number={1} title="Event Summary" icon={Calendar}>
              <Row label="Event date" value={floodData.eventDateDisplay} />
              <Row label="Location" value={floodData.location} />
              <Row label="Pre-event acquisition" value={floodData.preDateDisplay} />
              <Row label="Post-event acquisition" value={floodData.postDateDisplay} />
              <Row label="Satellite" value={`${floodData.satellite} SAR`} />
            </ReportSection>

            {/* 2. Satellite Information */}
            <ReportSection number={2} title="Satellite Information" icon={Satellite}>
              <Row label="Platform" value={floodData.satellite} />
              <Row label="Mode" value={floodData.mode} />
              <Row label="Pass direction" value={floodData.passDirection} />
              <Row label="Relative orbit" value={String(floodData.relativeOrbit)} />
              <Row label="Polarization" value={floodData.polarizationDisplay} />
              <Row label="Spatial resolution" value={`${floodData.resolution} m`} />
              <Row label="Effective looks" value={String(floodData.effectiveLooks)} />
              <Row label="Pre-event scene" value={floodData.preSceneId} mono />
              <Row label="Post-event scene" value={floodData.postSceneId} mono />
            </ReportSection>

            {/* 3. Flood Detection */}
            <ReportSection number={3} title="Flood Detection" icon={Settings2}>
              <Row label="Detection method" value={floodData.detectionMethod} />
              <Row label="Statistical threshold" value={floodData.significanceDisplay} />
              <Row label="Confidence wording" value={floodData.confidenceWording} />
              <p className="text-xs text-[#6b7280] mt-2">
                The change-detection approach compares per-pixel VV and VH backscatter
                distributions between pre- and post-event Sentinel-1 acquisitions. Pixels
                whose change exceeds the statistical significance threshold ({floodData.significanceDisplay})
                are flagged as candidate flood pixels.
              </p>
            </ReportSection>

            {/* 4. Flood Extent */}
            <ReportSection number={4} title="Flood Extent" icon={Waves}>
              <Row label="Square meters" value={floodData.floodAreaM2Display} />
              <Row label="Hectares" value={floodData.floodAreaHaDisplay} />
              <Row label="Square kilometers" value={floodData.floodAreaKm2Display} />
              <Row label="Pre-event baseline" value={floodData.preFloodAreaKm2Display} />
            </ReportSection>

            {/* 5. Land Cover */}
            <ReportSection number={5} title="Land Cover" icon={Layers3}>
              <Row label="Vegetation" value={`${floodData.vegetationDisplay} (${floodData.vegetationPct}%)`} />
              <Row label="Bare / Sparse Land" value={`${floodData.bareLandDisplay} (${floodData.bareLandPct}%)`} />
              <Row label="Cropland" value={`${floodData.croplandDisplay} (${floodData.croplandPct}%)`} />
              <Row label="Built-up" value={`${floodData.builtUpDisplay} (${floodData.builtUpPct}%)`} />
              <Row label="Other / Unclassified" value={`${floodData.otherDisplay} (${floodData.otherPct}%)`} />
            </ReportSection>

            {/* 6. Infrastructure Exposure (MODELLED) */}
            <ReportSection number={6} title="Infrastructure Exposure" icon={Route}>
              <div className="flex items-center gap-2 mb-2">
                <ModelledBadge size="sm" />
              </div>
              <Row label="Affected road length" value={`${floodData.modelledImpact.affectedRoadKm} km`} muted />
              <Row label="Affected buildings" value={String(floodData.modelledImpact.affectedBuildings)} muted />
              <Row label="Affected bridges" value={String(floodData.modelledImpact.affectedBridges)} muted />
              <Row label="Infrastructure exposure" value={floodData.modelledImpact.infrastructureExposure} muted />
            </ReportSection>

            {/* 7. Population Exposure (MODELLED) */}
            <ReportSection number={7} title="Population Exposure" icon={Users}>
              <div className="flex items-center gap-2 mb-2">
                <ModelledBadge size="sm" />
              </div>
              <Row label="Estimated population exposure" value={`${floodData.modelledImpact.populationExposure} people`} muted />
              <Row label="Affected settlement area" value={`${floodData.modelledImpact.settlementHa} ha`} muted />
              <Row label="Affected agriculture" value={`${floodData.modelledImpact.agricultureHa} ha`} muted />
            </ReportSection>

            {/* 8. Risk Score (MODELLED) */}
            <ReportSection number={8} title="Risk Score" icon={Gauge}>
              <div className="flex items-center gap-2 mb-2">
                <ModelledBadge size="sm" />
              </div>
              <Row label="Rapid impact score" value={`${floodData.riskScore.total} / ${floodData.riskScore.max}`} muted />
              <Row label="Classification" value={floodData.riskScore.classification} muted />
              {floodData.riskScore.breakdown.map((b) => (
                <Row
                  key={b.label}
                  label={b.label}
                  value={`${b.score} / ${b.max}`}
                  muted
                />
              ))}
              <Row label="Impact level" value={floodData.modelledImpact.impactLevel} muted />
            </ReportSection>

            {/* 9. Methodology */}
            <ReportSection number={9} title="Methodology" icon={Settings2}>
              <ol className="space-y-1.5 list-none">
                {methodologyFlow.map((step) => (
                  <li key={step.step} className="text-xs">
                    <span className="font-semibold text-[#0B4F3A]">
                      {step.step}. {step.label}
                    </span>
                    <span className="text-[#6b7280]"> &mdash; {step.description}</span>
                  </li>
                ))}
              </ol>
            </ReportSection>

            {/* 10. Data Sources */}
            <ReportSection number={10} title="Data Sources" icon={Database}>
              <Row label="Satellite imagery" value="Sentinel-1 SAR (Copernicus)" />
              <Row label="Processing platform" value="Google Earth Engine" />
              <Row label="Land cover" value="ESA WorldCover (10 m)" />
              <Row label="Roads / Buildings / Bridges" value="Modelled prototype estimates" muted />
              <Row label="Population" value="Modelled prototype estimates" muted />
              <Row label="Map layer status" value={earthEngineLayer.label} muted />
            </ReportSection>

            {/* 11. Limitations */}
            <ReportSection number={11} title="Limitations" icon={ShieldAlert}>
              <ul className="space-y-1.5 text-xs text-[#6b7280] list-disc pl-4">
                <li>
                  Flood detection results are derived from Sentinel-1 SAR backscatter
                  change detection and have not been field-validated.
                </li>
                <li>
                  Roads, buildings, bridges and population exposure are modelled
                  prototype estimates and are clearly labelled &ldquo;Modelled
                  estimate&rdquo; throughout this report.
                </li>
                <li>
                  The map flood raster is currently rendered as an
                  &ldquo;{earthEngineLayer.label}&rdquo;; the live Earth Engine tile
                  endpoint can be connected via the integration module.
                </li>
                <li>
                  SAR change detection can be affected by wind-roughened water surfaces,
                  vegetation phenology, and dry soil conditions.
                </li>
                <li>
                  The Rapid Impact Score is a prototype decision-support score, not an
                  officially validated disaster-risk index.
                </li>
              </ul>
            </ReportSection>

            <div className="border-t border-[#e2e8e0] pt-3 flex items-center gap-2 text-[11px] text-[#9ca3af]">
              <CheckCircle2 className="h-3.5 w-3.5 text-[#0B4F3A]" />
              End of report &middot; RasUwa FloodLens &middot; Generated {floodData.lastUpdatedDisplay}
            </div>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="print:hidden">
          <ModelledDisclaimerBanner />
        </div>
      </div>
    </div>
  );
}

function ReportSection({
  number,
  title,
  icon: Icon,
  children,
}: {
  number: number;
  title: string;
  icon: typeof FileText;
  children: React.ReactNode;
}) {
  return (
    <section className="space-y-2">
      <div className="flex items-center gap-2 border-b border-[#e2e8e0] pb-1.5">
        <span
          className="flex h-6 w-6 items-center justify-center rounded-md text-[11px] font-bold text-white"
          style={{ background: "#0B4F3A" }}
        >
          {number}
        </span>
        <Icon className="h-3.5 w-3.5 text-[#0B4F3A]" />
        <h3 className="text-sm font-semibold text-[#0f172a]">{title}</h3>
      </div>
      <div className="pl-8 space-y-1">{children}</div>
    </section>
  );
}

function Row({
  label,
  value,
  mono,
  muted,
}: {
  label: string;
  value: string;
  mono?: boolean;
  muted?: boolean;
}) {
  return (
    <div className="flex items-start gap-3 text-xs py-0.5">
      <span className="text-[#6b7280] w-44 shrink-0">{label}</span>
      <span
        className={`flex-1 ${mono ? "font-mono text-[11px] break-all" : "font-medium"} ${
          muted ? "text-[#9ca3af] italic" : "text-[#374151]"
        }`}
      >
        {value}
      </span>
    </div>
  );
}
