"use client";

import dynamic from "next/dynamic";
import { KpiCards } from "../kpi-cards";
import { FloodAnalysisPanel } from "../flood-analysis-panel";
import { LandCoverChart } from "../land-cover-chart";
import { FloodExtentComparisonChart } from "../flood-extent-comparison-chart";
import { ImpactSummaryChart } from "../impact-summary-chart";
import { SeverityChart } from "../severity-chart";
import { RapidImpactScore } from "../rapid-impact-score";
import { DecisionSupport, DataStatus } from "../decision-support";
import { ModelledDisclaimerBanner } from "../modelled-badge";

// Leaflet requires `window`; load the map client-side only.
const FloodMap = dynamic(() => import("../map/flood-map").then((m) => m.FloodMap), {
  ssr: false,
  loading: () => (
    <div className="h-full w-full flex items-center justify-center text-sm text-[#9ca3af]">
      Loading map...
    </div>
  ),
});

export function DashboardView() {
  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto fl-scroll">
        <div className="p-4 md:p-5 space-y-4">
          <KpiCards />

          {/* Modelled disclaimer banner */}
          <ModelledDisclaimerBanner />

          {/* 3-column dashboard: map + right panel */}
          <div className="grid grid-cols-1 xl:grid-cols-[1fr_340px] gap-4">
            {/* Map card */}
            <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
              <div className="flex items-center justify-between px-4 py-3 border-b border-[#e2e8e0]">
                <div>
                  <h2 className="text-sm font-semibold text-[#0f172a]">Study Area Map</h2>
                  <p className="text-[11px] text-[#6b7280] mt-0.5">
                    Rasuwa District &middot; Sentinel-1 SAR change detection
                  </p>
                </div>
                <span className="text-[10px] uppercase tracking-wide text-[#9ca3af] font-medium">
                  Interactive
                </span>
              </div>
              <div className="h-[480px] md:h-[560px] lg:h-[640px] p-2">
                <FloodMap />
              </div>
            </div>

            {/* Right analysis panel */}
            <div className="space-y-4">
              <FloodAnalysisPanel />
              <LandCoverChart />
              <FloodExtentComparisonChart />
              <DataStatus />
            </div>
          </div>

          {/* Impact summary + severity */}
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-4">
            <ImpactSummaryChart />
            <SeverityChart />
          </div>

          {/* Rapid impact score */}
          <RapidImpactScore />

          {/* Decision support full-width */}
          <DecisionSupport />
        </div>
      </div>
    </div>
  );
}
