"use client";

import {
  Satellite,
  Radar,
  Radio,
  Waves,
  Activity,
  Calendar,
  Cpu,
  Orbit,
} from "lucide-react";
import { floodData } from "@/lib/flood-data";

export function SatelliteDataView() {
  return (
    <div className="overflow-y-auto fl-scroll h-full">
      <div className="p-4 md:p-6 max-w-6xl mx-auto space-y-5">
        {/* Page header */}
        <div className="flex items-center gap-3">
          <div
            className="flex h-10 w-10 items-center justify-center rounded-lg"
            style={{ background: "#0B4F3A" }}
          >
            <Satellite className="h-5 w-5 text-cyan-300" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-[#0f172a]">Satellite Data</h2>
            <p className="text-xs text-[#6b7280] mt-0.5">
              Sentinel-1 IW GRD scenes used for flood detection
            </p>
          </div>
        </div>

        {/* Platform summary */}
        <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
          <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center gap-2">
            <Cpu className="h-4 w-4 text-[#0B4F3A]" />
            <h3 className="text-sm font-semibold text-[#0f172a]">Platform Information</h3>
          </div>
          <div className="p-4 grid grid-cols-2 md:grid-cols-4 gap-3">
            <InfoCell icon={Satellite} label="Platform" value={floodData.satellite} />
            <InfoCell icon={Radio} label="Mode" value={floodData.mode} />
            <InfoCell icon={Orbit} label="Pass" value={floodData.passDirection} />
            <InfoCell icon={Radar} label="Relative Orbit" value={String(floodData.relativeOrbit)} />
            <InfoCell icon={Waves} label="Polarization" value={floodData.polarizationDisplay} />
            <InfoCell icon={Activity} label="Resolution" value={`${floodData.resolution} m`} />
            <InfoCell icon={Cpu} label="Effective looks" value={String(floodData.effectiveLooks)} />
            <InfoCell icon={Calendar} label="Acquisitions" value="2 scenes" />
          </div>
        </div>

        {/* Pre-event scene */}
        <SceneCard
          title="Pre-event Scene"
          sceneId={floodData.preSceneId}
          date={floodData.preDateDisplay}
          phase="pre"
        />

        {/* Post-event scene */}
        <SceneCard
          title="Post-event Scene"
          sceneId={floodData.postSceneId}
          date={floodData.postDateDisplay}
          phase="post"
        />

        {/* Acquisition gap */}
        <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
          <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center gap-2">
            <Calendar className="h-4 w-4 text-[#0B4F3A]" />
            <h3 className="text-sm font-semibold text-[#0f172a]">Acquisition Gap</h3>
          </div>
          <div className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <p className="text-sm text-[#374151]">
                Time between pre- and post-event acquisitions
              </p>
              <p className="text-xs text-[#9ca3af] mt-1">
                Both scenes from same relative orbit ({floodData.relativeOrbit}) for
                consistent backscatter comparison.
              </p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-[#0B4F3A]" style={{ fontVariantNumeric: "tabular-nums" }}>
                12 days
              </p>
              <p className="text-[10px] text-[#9ca3af] uppercase tracking-wide">
                Sentinel-1 repeat cycle
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface SceneCardProps {
  title: string;
  sceneId: string;
  date: string;
  phase: "pre" | "post";
}

function SceneCard({ title, sceneId, date, phase }: SceneCardProps) {
  const isPre = phase === "pre";
  const accentColor = isPre ? "#4B5563" : "#1F2937";
  const bg = isPre ? "#F9FAFB" : "#F3F4F6";

  // Parse scene ID for component breakdown
  const parts = sceneId.split("_");

  return (
    <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
      <div
        className="px-4 py-3 border-b border-[#e2e8e0] flex items-center justify-between"
        style={{ background: bg }}
      >
        <div className="flex items-center gap-2">
          <Satellite className="h-4 w-4" style={{ color: accentColor }} />
          <h3 className="text-sm font-semibold text-[#0f172a]">{title}</h3>
        </div>
        <span
          className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide"
          style={{ background: "#ffffff", color: accentColor, border: `1px solid ${accentColor}33` }}
        >
          <Calendar className="h-3 w-3" />
          {date}
        </span>
      </div>

      <div className="p-4 space-y-3">
        <div>
          <p className="text-[10px] uppercase tracking-wide text-[#9ca3af] font-semibold mb-1">
            Scene Identifier
          </p>
          <code
            className="block text-[11px] md:text-xs font-mono bg-[#0B4F3A] text-cyan-200 rounded-md p-3 break-all leading-relaxed"
          >
            {sceneId}
          </code>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
          <SceneTag label="Mission" value={parts[0] ?? "S1D"} />
          <SceneTag label="Mode" value={parts[1] ?? "IW"} />
          <SceneTag label="Product" value={parts[2] ?? "GRDH"} />
          <SceneTag label="Resolution" value={parts[3] ?? "1SDV"} />
        </div>
      </div>
    </div>
  );
}

function SceneTag({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-[#f9fafb] rounded-md p-2 border border-[#f1f5f3]">
      <p className="text-[9px] uppercase tracking-wide text-[#9ca3af] font-semibold">{label}</p>
      <p className="text-xs font-semibold text-[#374151] font-mono mt-0.5">{value}</p>
    </div>
  );
}

function InfoCell({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Satellite;
  label: string;
  value: string;
}) {
  return (
    <div className="bg-[#f9fafb] rounded-lg p-3 border border-[#f1f5f3]">
      <div className="flex items-center gap-1.5 text-[#9ca3af]">
        <Icon className="h-3 w-3" />
        <p className="text-[10px] uppercase tracking-wide font-semibold">{label}</p>
      </div>
      <p className="text-sm font-semibold text-[#374151] mt-1">{value}</p>
    </div>
  );
}
