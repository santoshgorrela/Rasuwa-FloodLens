"use client";

import {
  Waves,
  Leaf,
  Mountain,
  Wheat,
  Building2,
  Layers3,
  AlertTriangle,
  Route,
  Home,
  Construction,
  Users,
  Info,
  Gauge,
  ShieldAlert,
} from "lucide-react";
import { floodData } from "@/lib/flood-data";
import { ModelledBadge, ModelledDisclaimerBanner } from "../modelled-badge";

export function ImpactAssessmentView() {
  const landCoverRows = [
    { icon: Leaf, label: "Vegetation", value: floodData.vegetationDisplay, pct: floodData.vegetationPct, color: "#16A34A" },
    { icon: Mountain, label: "Bare / Sparse", value: floodData.bareLandDisplay, pct: floodData.bareLandPct, color: "#D97706" },
    { icon: Wheat, label: "Cropland", value: floodData.croplandDisplay, pct: floodData.croplandPct, color: "#CA8A04" },
    { icon: Building2, label: "Built-up", value: floodData.builtUpDisplay, pct: floodData.builtUpPct, color: "#B91C1C" },
    { icon: Layers3, label: "Other / Unclassified", value: floodData.otherDisplay, pct: floodData.otherPct, color: "#6B7280" },
  ];

  return (
    <div className="overflow-y-auto fl-scroll h-full">
      <div className="p-4 md:p-6 max-w-6xl mx-auto space-y-5">
        {/* Page header */}
        <div className="flex items-center gap-3">
          <div
            className="flex h-10 w-10 items-center justify-center rounded-lg"
            style={{ background: "#0B4F3A" }}
          >
            <AlertTriangle className="h-5 w-5 text-amber-300" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-[#0f172a]">Impact Assessment</h2>
            <p className="text-xs text-[#6b7280] mt-0.5">
              Flood exposure analysis &middot; Sentinel-1 SAR + modelled infrastructure estimates
            </p>
          </div>
        </div>

        {/* Modelled disclaimer banner */}
        <ModelledDisclaimerBanner />

        {/* FLOOD EXPOSURE */}
        <SectionCard title="Flood Exposure" icon={Waves} iconColor="#06B6D4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <StatTile label="Flood extent" value={floodData.floodAreaHaDisplay} sublabel="hectares" accent="#0E7490" />
            <StatTile label="Equivalent" value={floodData.floodAreaKm2Display} sublabel="square kilometers" accent="#0E7490" />
            <StatTile label="Raw" value={floodData.floodAreaM2Display} sublabel="square meters" accent="#0E7490" />
          </div>
        </SectionCard>

        {/* LAND COVER */}
        <SectionCard title="Land Cover" icon={Layers3} iconColor="#0B4F3A">
          <div className="space-y-2">
            {landCoverRows.map((row) => {
              const Icon = row.icon;
              return (
                <div
                  key={row.label}
                  className="flex items-center gap-3 rounded-lg p-2.5 bg-[#f9fafb] border border-[#f1f5f3]"
                >
                  <span
                    className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md"
                    style={{ background: `${row.color}1a`, color: row.color }}
                  >
                    <Icon className="h-3.5 w-3.5" />
                  </span>
                  <span className="text-sm text-[#374151] font-medium flex-1">{row.label}</span>
                  <span
                    className="text-[10px] font-semibold px-1.5 py-0.5 rounded"
                    style={{ background: `${row.color}1a`, color: row.color }}
                  >
                    {row.pct}%
                  </span>
                  <span
                    className="text-sm font-semibold w-24 text-right"
                    style={{ color: row.color, fontVariantNumeric: "tabular-nums" }}
                  >
                    {row.value}
                  </span>
                </div>
              );
            })}
          </div>
        </SectionCard>

        {/* INFRASTRUCTURE (MODELLED) */}
        <ModelledSectionCard title="Infrastructure" icon={Route} iconColor="#F97316">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <ModelledStatTile
              icon={Route}
              label="Roads"
              value={`${floodData.modelledImpact.affectedRoadKm} km`}
              sublabel="Affected length"
              color="#F97316"
            />
            <ModelledStatTile
              icon={Home}
              label="Buildings"
              value={String(floodData.modelledImpact.affectedBuildings)}
              sublabel="Affected footprints"
              color="#DC2626"
            />
            <ModelledStatTile
              icon={Construction}
              label="Bridges"
              value={String(floodData.modelledImpact.affectedBridges)}
              sublabel="Affected structures"
              color="#9333EA"
            />
          </div>
          <div className="mt-3 flex items-center gap-2 text-xs text-[#6b7280]">
            <Info className="h-3.5 w-3.5" />
            Infrastructure exposure: <span className="font-semibold text-[#92400E]">{floodData.modelledImpact.infrastructureExposure}</span>
          </div>
        </ModelledSectionCard>

        {/* POPULATION (MODELLED) */}
        <ModelledSectionCard title="Population" icon={Users} iconColor="#0284C7">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <ModelledStatTile
              icon={Users}
              label="Estimated population exposure"
              value={String(floodData.modelledImpact.populationExposure)}
              sublabel="people"
              color="#0284C7"
            />
            <ModelledStatTile
              icon={Home}
              label="Affected settlement area"
              value={`${floodData.modelledImpact.settlementHa} ha`}
              sublabel="hectares"
              color="#0284C7"
            />
          </div>
        </ModelledSectionCard>

        {/* AGRICULTURE (MODELLED) */}
        <ModelledSectionCard title="Agriculture" icon={Wheat} iconColor="#16A34A">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <ModelledStatTile
              icon={Wheat}
              label="Affected agriculture"
              value={`${floodData.modelledImpact.agricultureHa} ha`}
              sublabel="hectares"
              color="#16A34A"
            />
            <ModelledStatTile
              icon={Layers3}
              label="Detected cropland overlap"
              value={floodData.croplandDisplay}
              sublabel="from land-cover analysis"
              color="#CA8A04"
            />
          </div>
        </ModelledSectionCard>

        {/* IMPACT LEVEL */}
        <SectionCard title="Impact Level" icon={Gauge} iconColor="#DC2626">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-3">
                <span
                  className="text-3xl font-bold"
                  style={{ color: "#D97706", fontVariantNumeric: "tabular-nums" }}
                >
                  {floodData.modelledImpact.impactLevel.toUpperCase()}
                </span>
                <ModelledBadge size="md" />
              </div>
              <p className="text-xs text-[#6b7280] mt-1">
                Prototype decision-support classification based on modelled exposure estimates.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3 sm:w-64">
              <MiniStat label="Infrastructure" value={floodData.modelledImpact.infrastructureExposure} color="#D97706" />
              <MiniStat label="Risk score" value={`${floodData.riskScore.total}/${floodData.riskScore.max}`} color="#DC2626" />
            </div>
          </div>
        </SectionCard>

        {/* Disclaimer */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
          <ShieldAlert className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-amber-800">Important note on impact estimates</p>
            <p className="text-xs text-amber-700 mt-1 leading-relaxed">
              Roads, buildings, bridges and population exposure are modelled prototype
              estimates for decision-support demonstration. They are derived from
              illustrative infrastructure patterns appropriate to the detected flood
              footprint and must be replaced with validated infrastructure and population
              datasets before operational use. They should not be interpreted as
              field-confirmed impact.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SectionCard({
  title,
  icon: Icon,
  iconColor,
  children,
}: {
  title: string;
  icon: typeof Waves;
  iconColor: string;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
      <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center gap-2">
        <Icon className="h-4 w-4" style={{ color: iconColor }} />
        <h3 className="text-sm font-semibold text-[#0f172a]">{title}</h3>
      </div>
      <div className="p-4">{children}</div>
    </div>
  );
}

function ModelledSectionCard({
  title,
  icon: Icon,
  iconColor,
  children,
}: {
  title: string;
  icon: typeof Waves;
  iconColor: string;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
      <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Icon className="h-4 w-4" style={{ color: iconColor }} />
          <h3 className="text-sm font-semibold text-[#0f172a]">{title}</h3>
        </div>
        <ModelledBadge size="sm" />
      </div>
      <div className="p-4">{children}</div>
    </div>
  );
}

function StatTile({
  label,
  value,
  sublabel,
  accent,
}: {
  label: string;
  value: string;
  sublabel: string;
  accent: string;
}) {
  return (
    <div
      className="rounded-lg p-3 border"
      style={{ background: `${accent}0a`, borderColor: `${accent}33` }}
    >
      <p className="text-[10px] uppercase tracking-wide font-semibold" style={{ color: `${accent}cc` }}>
        {label}
      </p>
      <p className="text-lg font-bold mt-1" style={{ color: accent, fontVariantNumeric: "tabular-nums" }}>
        {value}
      </p>
      <p className="text-[10px] text-[#9ca3af] mt-0.5">{sublabel}</p>
    </div>
  );
}

function ModelledStatTile({
  icon: Icon,
  label,
  value,
  sublabel,
  color,
}: {
  icon: typeof Route;
  label: string;
  value: string;
  sublabel: string;
  color: string;
}) {
  return (
    <div
      className="rounded-lg p-3 border flex items-start gap-3"
      style={{ background: `${color}0a`, borderColor: `${color}33` }}
    >
      <span
        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md"
        style={{ background: "#ffffff", color }}
      >
        <Icon className="h-4 w-4" />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-[10px] uppercase tracking-wide font-semibold" style={{ color: `${color}cc` }}>
          {label}
        </p>
        <p className="text-xl font-bold mt-0.5" style={{ color, fontVariantNumeric: "tabular-nums" }}>
          {value}
        </p>
        <p className="text-[10px] text-[#9ca3af] mt-0.5">{sublabel}</p>
      </div>
    </div>
  );
}

function MiniStat({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="rounded-lg p-2.5 bg-[#f9fafb] border border-[#f1f5f3]">
      <p className="text-[10px] uppercase tracking-wide text-[#9ca3af] font-semibold">{label}</p>
      <p className="text-sm font-bold mt-0.5" style={{ color }}>
        {value}
      </p>
    </div>
  );
}
