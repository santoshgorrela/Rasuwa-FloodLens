"use client";

import {
  Info,
  Satellite,
  Radar,
  Sigma,
  Waves,
  Layers3,
  Database,
  ArrowDown,
  Cloud,
  CheckCircle2,
  GitBranch,
} from "lucide-react";
import { floodData, methodologyFlow, earthEngineLayer } from "@/lib/flood-data";

export function AboutView() {
  return (
    <div className="overflow-y-auto fl-scroll h-full">
      <div className="p-4 md:p-6 max-w-5xl mx-auto space-y-5">
        {/* Page header */}
        <div className="flex items-center gap-3">
          <div
            className="flex h-10 w-10 items-center justify-center rounded-lg"
            style={{ background: "#0B4F3A" }}
          >
            <Info className="h-5 w-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-[#0f172a]">About / GEE</h2>
            <p className="text-xs text-[#6b7280] mt-0.5">
              Workflow, methodology and Google Earth Engine integration
            </p>
          </div>
        </div>

        {/* Overview */}
        <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
          <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center gap-2">
            <Satellite className="h-4 w-4 text-[#0B4F3A]" />
            <h3 className="text-sm font-semibold text-[#0f172a]">Overview</h3>
          </div>
          <div className="p-4 space-y-3 text-sm text-[#374151] leading-relaxed">
            <p>
              <strong className="text-[#0B4F3A]">RasUwa FloodLens</strong> is a rapid
              flood mapping and impact assessment dashboard for Rasuwa District, Nepal.
              It uses Sentinel-1 Synthetic Aperture Radar (SAR) imagery to detect
              inundation following the {floodData.eventDateDisplay} flood event.
            </p>
            <p>
              Sentinel-1 SAR is particularly useful for flood mapping because radar can
              acquire imagery regardless of cloud conditions, allowing detection even
              during monsoon storms when optical satellites are obstructed.
            </p>
          </div>
        </div>

        {/* Methodology flow */}
        <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
          <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center gap-2">
            <Layers3 className="h-4 w-4 text-[#0B4F3A]" />
            <h3 className="text-sm font-semibold text-[#0f172a]">Methodology Workflow</h3>
          </div>
          <div className="p-4">
            <div className="space-y-2">
              {methodologyFlow.map((step, idx) => (
                <div key={step.step}>
                  <div
                    className="flex items-start gap-3 rounded-lg p-3 border border-[#e2e8e0]"
                    style={{ background: idx === methodologyFlow.length - 1 ? "#E6F0EB" : "#f9fafb" }}
                  >
                    <span
                      className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-[11px] font-bold"
                      style={{
                        background: idx === methodologyFlow.length - 1 ? "#0B4F3A" : "#0B4F3A22",
                        color: idx === methodologyFlow.length - 1 ? "#ffffff" : "#0B4F3A",
                      }}
                    >
                      {step.step}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-[#0f172a]">{step.label}</p>
                      <p className="text-xs text-[#6b7280] mt-0.5">{step.description}</p>
                    </div>
                    {idx === methodologyFlow.length - 1 && (
                      <CheckCircle2 className="h-4 w-4 text-[#0B4F3A] shrink-0 mt-0.5" />
                    )}
                  </div>
                  {idx < methodologyFlow.length - 1 && (
                    <div className="flex justify-center py-1">
                      <ArrowDown className="h-4 w-4 text-[#9ca3af]" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Key components */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <InfoCard
            icon={Satellite}
            title="Sentinel-1 SAR"
            color="#0B4F3A"
            items={[
              { label: "Platform", value: floodData.satellite },
              { label: "Mode", value: floodData.mode },
              { label: "Resolution", value: `${floodData.resolution} m` },
              { label: "Polarization", value: floodData.polarizationDisplay },
            ]}
          />
          <InfoCard
            icon={Sigma}
            title="Statistical Detection"
            color="#0E7490"
            items={[
              { label: "Method", value: "Per-pixel change detection" },
              { label: "Threshold", value: floodData.significanceDisplay },
              { label: "Confidence", value: floodData.confidenceWording },
              { label: "Looks", value: String(floodData.effectiveLooks) },
            ]}
          />
          <InfoCard
            icon={Radar}
            title="Acquisition Geometry"
            color="#7C3AED"
            items={[
              { label: "Pass", value: floodData.passDirection },
              { label: "Relative orbit", value: String(floodData.relativeOrbit) },
              { label: "Pre-event", value: floodData.preDateDisplay },
              { label: "Post-event", value: floodData.postDateDisplay },
            ]}
          />
          <InfoCard
            icon={Database}
            title="Study Area"
            color="#D97706"
            items={[
              { label: "Location", value: floodData.location },
              { label: "AOI bounds (lon)", value: "85.10 – 85.50" },
              { label: "AOI bounds (lat)", value: "27.90 – 28.38" },
              { label: "Center", value: `${floodData.aoi.center[0].toFixed(2)}°N, ${floodData.aoi.center[1].toFixed(2)}°E` },
            ]}
          />
        </div>

        {/* Earth Engine integration */}
        <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
          <div
            className="px-4 py-3 border-b border-[#e2e8e0] flex items-center justify-between"
            style={{ background: "linear-gradient(90deg, #0B4F3A 0%, #1B7A5A 100%)" }}
          >
            <div className="flex items-center gap-2">
              <Cloud className="h-4 w-4 text-cyan-300" />
              <h3 className="text-sm font-semibold text-white">Google Earth Engine Integration</h3>
            </div>
            <span
              className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide"
              style={{ background: "rgba(6, 182, 212, 0.18)", color: "#a5f3fc" }}
            >
              <Cloud className="h-3 w-3" />
              GEE Pipeline
            </span>
          </div>

          <div className="p-4 space-y-4">
            <div className="space-y-3">
              <p className="text-sm text-[#374151]">
                The dashboard is architected to consume flood raster tiles directly from
                Google Earth Engine once the live endpoint is connected. The data flow
                is:
              </p>

              <div className="rounded-lg p-3 bg-[#f9fafb] border border-[#f1f5f3]">
                <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
                  <Pill icon={Cloud} label="Google Earth Engine" color="#0B4F3A" />
                  <ArrowDown className="h-3.5 w-3.5 text-[#9ca3af] rotate-[-90deg]" />
                  <Pill icon={Satellite} label="Sentinel-1 processing" color="#0E7490" />
                  <ArrowDown className="h-3.5 w-3.5 text-[#9ca3af] rotate-[-90deg]" />
                  <Pill icon={Waves} label="Flood raster" color="#06B6D4" />
                  <ArrowDown className="h-3.5 w-3.5 text-[#9ca3af] rotate-[-90deg]" />
                  <Pill icon={Layers3} label="Web map layer" color="#16A34A" />
                  <ArrowDown className="h-3.5 w-3.5 text-[#9ca3af] rotate-[-90deg]" />
                  <Pill icon={Database} label="RasUwa FloodLens dashboard" color="#0B4F3A" />
                </div>
              </div>
            </div>

            <div
              className="rounded-lg p-3 flex items-start gap-2"
              style={{ background: earthEngineLayer.connected ? "#DCFCE7" : "#FEF3C7" }}
            >
              {earthEngineLayer.connected ? (
                <CheckCircle2 className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />
              ) : (
                <GitBranch className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
              )}
              <div className="text-xs">
                <p
                  className="font-semibold"
                  style={{ color: earthEngineLayer.connected ? "#166534" : "#92400E" }}
                >
                  {earthEngineLayer.connected
                    ? "Live Earth Engine layer connected"
                    : `Current status: ${earthEngineLayer.label}`}
                </p>
                <p
                  className="mt-1"
                  style={{ color: earthEngineLayer.connected ? "#15803d" : "#92400E" }}
                >
                  {earthEngineLayer.connected
                    ? "Map tiles are being served from the Earth Engine tile endpoint."
                    : "The flood detection has been produced by Earth Engine; the live tile endpoint is not yet wired into this deployment. The map currently renders an Analysis Preview overlay. Once a tile URL template is supplied to the EarthEngineLayerConfig, the real flood raster will display automatically."}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
          <Info className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-amber-800">Important</p>
            <p className="text-xs text-amber-700 mt-1 leading-relaxed">
              This dashboard does not make unsupported claims about exact ground impact.
              All exposure metrics depend on the available analysis layers and are not
              field-validated.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoCard({
  icon: Icon,
  title,
  color,
  items,
}: {
  icon: typeof Satellite;
  title: string;
  color: string;
  items: { label: string; value: string }[];
}) {
  return (
    <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
      <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center gap-2">
        <span
          className="flex h-7 w-7 items-center justify-center rounded-md"
          style={{ background: `${color}1a`, color }}
        >
          <Icon className="h-3.5 w-3.5" />
        </span>
        <h3 className="text-sm font-semibold text-[#0f172a]">{title}</h3>
      </div>
      <div className="p-4 space-y-1.5">
        {items.map((item) => (
          <div key={item.label} className="flex items-center justify-between text-xs">
            <span className="text-[#6b7280]">{item.label}</span>
            <span className="font-semibold text-[#374151]" style={{ fontVariantNumeric: "tabular-nums" }}>
              {item.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function Pill({
  icon: Icon,
  label,
  color,
}: {
  icon: typeof Cloud;
  label: string;
  color: string;
}) {
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium"
      style={{ background: `${color}14`, color }}
    >
      <Icon className="h-3 w-3" />
      {label}
    </span>
  );
}
