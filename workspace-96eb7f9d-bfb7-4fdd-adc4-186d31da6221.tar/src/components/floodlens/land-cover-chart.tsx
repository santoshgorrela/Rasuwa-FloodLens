"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Cell,
  Tooltip,
  Cell as RechartsCell,
} from "recharts";
import { Leaf, Mountain, Wheat, Building2, Layers3, Sigma } from "lucide-react";
import { floodData } from "@/lib/flood-data";

interface LandCoverRow {
  key: string;
  label: string;
  valueM2: number;
  display: string;
  pct: number;
  color: string;
  icon: typeof Leaf;
}

const rows: LandCoverRow[] = [
  {
    key: "vegetation",
    label: "Vegetation",
    valueM2: floodData.vegetationM2,
    display: floodData.vegetationDisplay,
    pct: floodData.vegetationPct,
    color: "#16A34A",
    icon: Leaf,
  },
  {
    key: "bare",
    label: "Bare / Sparse",
    valueM2: floodData.bareLandM2,
    display: floodData.bareLandDisplay,
    pct: floodData.bareLandPct,
    color: "#D97706",
    icon: Mountain,
  },
  {
    key: "cropland",
    label: "Cropland",
    valueM2: floodData.croplandM2,
    display: floodData.croplandDisplay,
    pct: floodData.croplandPct,
    color: "#CA8A04",
    icon: Wheat,
  },
  {
    key: "builtup",
    label: "Built-up",
    valueM2: floodData.builtUpM2,
    display: floodData.builtUpDisplay,
    pct: floodData.builtUpPct,
    color: "#B91C1C",
    icon: Building2,
  },
  {
    key: "other",
    label: "Other / Unclassified",
    valueM2: floodData.otherM2,
    display: floodData.otherDisplay,
    pct: floodData.otherPct,
    color: "#6B7280",
    icon: Layers3,
  },
];

export function LandCoverChart() {
  const maxValue = Math.max(...rows.map((r) => r.valueM2), 1);

  return (
    <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
      <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Layers3 className="h-4 w-4 text-[#0B4F3A]" />
          <h3 className="text-sm font-semibold text-[#0f172a]">Flooded Land Cover</h3>
        </div>
        <span className="text-[10px] uppercase tracking-wide text-[#9ca3af] font-medium">
          m&sup2;
        </span>
      </div>

      <div className="p-4 space-y-3">
        {/* Total detected area header */}
        <div className="flex items-center justify-between rounded-lg p-2.5" style={{ background: "#E6F0EB" }}>
          <span className="flex items-center gap-1.5 text-xs font-medium text-[#0B4F3A]">
            <Sigma className="h-3.5 w-3.5" />
            Total Detected
          </span>
          <span className="text-sm font-bold text-[#0B4F3A]" style={{ fontVariantNumeric: "tabular-nums" }}>
            {floodData.floodAreaM2Display}
          </span>
        </div>

        {/* Horizontal bars with percentages */}
        <div className="space-y-2.5">
          {rows.map((row) => {
            const Icon = row.icon;
            const pct = (row.valueM2 / maxValue) * 100;
            return (
              <div key={row.key} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5 text-[#374151] font-medium">
                    <Icon className="h-3 w-3" style={{ color: row.color }} />
                    {row.label}
                  </span>
                  <span className="flex items-center gap-2">
                    <span
                      className="text-[10px] font-semibold px-1.5 py-0.5 rounded"
                      style={{ background: `${row.color}1a`, color: row.color }}
                    >
                      {row.pct}%
                    </span>
                    <span className="font-semibold text-[#0f172a]" style={{ fontVariantNumeric: "tabular-nums" }}>
                      {row.display}
                    </span>
                  </span>
                </div>
                <div className="h-2 w-full rounded-full bg-[#f1f5f3] overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.max(pct, row.valueM2 > 0 ? 3 : 0)}%`,
                      background: row.color,
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Compact chart */}
        <div className="h-32 mt-3 -ml-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={rows}
              layout="vertical"
              margin={{ top: 4, right: 8, bottom: 4, left: 8 }}
            >
              <XAxis type="number" hide domain={[0, "dataMax"]} />
              <YAxis type="category" dataKey="label" hide />
              <Tooltip
                cursor={{ fill: "rgba(11,79,58,0.05)" }}
                contentStyle={{
                  borderRadius: 8,
                  border: "1px solid #e2e8e0",
                  fontSize: 11,
                  padding: "6px 8px",
                }}
                formatter={(value: number) => [`${value.toFixed(2)} m²`, "Area"]}
                labelStyle={{ color: "#0B4F3A", fontWeight: 600 }}
              />
              <Bar dataKey="valueM2" radius={[0, 4, 4, 0]} barSize={12}>
                {rows.map((row) => (
                  <RechartsCell key={row.key} fill={row.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <p className="text-[10px] text-[#9ca3af] leading-tight">
          Percentages computed from the five supplied land-cover areas. Values are not field-validated.
        </p>
      </div>
    </div>
  );
}
