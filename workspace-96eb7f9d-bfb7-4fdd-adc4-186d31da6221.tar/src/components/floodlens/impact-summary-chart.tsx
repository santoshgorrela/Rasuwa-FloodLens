"use client";

import { Route, Home, Construction, Users, Wheat } from "lucide-react";
import { floodData } from "@/lib/flood-data";
import { ModelledBadge } from "./modelled-badge";

interface ImpactMetric {
  icon: typeof Route;
  label: string;
  value: string;
  sublabel: string;
  color: string;
  bg: string;
}

const metrics: ImpactMetric[] = [
  {
    icon: Route,
    label: "Roads",
    value: `${floodData.modelledImpact.affectedRoadKm} km`,
    sublabel: "Affected length",
    color: "#F97316",
    bg: "#FFEDD5",
  },
  {
    icon: Home,
    label: "Buildings",
    value: String(floodData.modelledImpact.affectedBuildings),
    sublabel: "Affected footprints",
    color: "#DC2626",
    bg: "#FEE2E2",
  },
  {
    icon: Construction,
    label: "Bridges",
    value: String(floodData.modelledImpact.affectedBridges),
    sublabel: "Affected structures",
    color: "#9333EA",
    bg: "#EDE9FE",
  },
  {
    icon: Users,
    label: "Population",
    value: String(floodData.modelledImpact.populationExposure),
    sublabel: "Estimated exposure",
    color: "#0284C7",
    bg: "#E0F2FE",
  },
  {
    icon: Wheat,
    label: "Agriculture",
    value: `${floodData.modelledImpact.agricultureHa} ha`,
    sublabel: "Affected area",
    color: "#16A34A",
    bg: "#DCFCE7",
  },
];

export function ImpactSummaryChart() {
  return (
    <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
      <div
        className="px-4 py-3 border-b border-[#e2e8e0] flex items-center justify-between"
        style={{ background: "linear-gradient(90deg, #0B4F3A 0%, #1B7A5A 100%)" }}
      >
        <div className="flex items-center gap-2">
          <Route className="h-4 w-4 text-amber-300" />
          <h3 className="text-sm font-semibold text-white">Impact Assessment</h3>
        </div>
        <ModelledBadge size="sm" />
      </div>

      <div className="p-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {metrics.map((m) => {
          const Icon = m.icon;
          return (
            <div
              key={m.label}
              className="rounded-lg p-3 border border-[#e2e8e0] flex flex-col gap-2 hover:shadow-sm transition-shadow"
              style={{ background: m.bg }}
            >
              <span
                className="flex h-7 w-7 items-center justify-center rounded-md"
                style={{ background: "#ffffff", color: m.color }}
              >
                <Icon className="h-3.5 w-3.5" />
              </span>
              <div>
                <p
                  className="text-lg font-bold leading-none"
                  style={{ color: m.color, fontVariantNumeric: "tabular-nums" }}
                >
                  {m.value}
                </p>
                <p className="text-[11px] font-medium text-[#374151] mt-1">{m.label}</p>
                <p className="text-[10px] text-[#6b7280] mt-0.5">{m.sublabel}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
