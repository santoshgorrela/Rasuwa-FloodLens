"use client";

import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, Tooltip } from "recharts";
import { BarChart3, TrendingUp } from "lucide-react";
import { floodData } from "@/lib/flood-data";

const data = [
  {
    label: "Before Event",
    value: floodData.preFloodAreaKm2,
    display: floodData.preFloodAreaKm2Display,
    color: "#9CA3AF",
  },
  {
    label: "Detected After Event",
    value: floodData.floodAreaKm2,
    display: floodData.floodAreaKm2Display,
    color: "#06B6D4",
  },
];

export function FloodExtentComparisonChart() {
  return (
    <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
      <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BarChart3 className="h-4 w-4 text-[#0B4F3A]" />
          <h3 className="text-sm font-semibold text-[#0f172a]">Flood Extent Comparison</h3>
        </div>
        <span className="text-[10px] uppercase tracking-wide text-[#9ca3af] font-medium">
          km&sup2;
        </span>
      </div>

      <div className="p-4 space-y-3">
        <div className="h-40">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 8, right: 8, bottom: 8, left: 8 }}>
              <XAxis
                dataKey="label"
                tick={{ fontSize: 10, fill: "#6b7280" }}
                axisLine={{ stroke: "#e2e8e0" }}
                tickLine={false}
              />
              <YAxis
                tick={{ fontSize: 10, fill: "#9ca3af" }}
                axisLine={false}
                tickLine={false}
                width={36}
                tickFormatter={(v: number) => v.toFixed(4)}
              />
              <Tooltip
                cursor={{ fill: "rgba(11,79,58,0.05)" }}
                contentStyle={{
                  borderRadius: 8,
                  border: "1px solid #e2e8e0",
                  fontSize: 11,
                  padding: "6px 8px",
                }}
                formatter={(value: number) => [`${value.toFixed(4)} km²`, "Area"]}
                labelStyle={{ color: "#0B4F3A", fontWeight: 600 }}
              />
              <Bar dataKey="value" radius={[6, 6, 0, 0]} barSize={64}>
                {data.map((row) => (
                  <Cell key={row.label} fill={row.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-lg p-2.5 border" style={{ background: "#f9fafb", borderColor: "#e2e8e0" }}>
            <p className="text-[10px] uppercase tracking-wide text-[#9ca3af] font-semibold">
              Before Event
            </p>
            <p className="text-sm font-bold text-[#6b7280] mt-0.5" style={{ fontVariantNumeric: "tabular-nums" }}>
              {floodData.preFloodAreaKm2Display}
            </p>
          </div>
          <div className="rounded-lg p-2.5 border" style={{ background: "#CFFAFE", borderColor: "#67e8f9" }}>
            <p className="text-[10px] uppercase tracking-wide text-[#0E7490] font-semibold">
              Detected After
            </p>
            <p className="text-sm font-bold text-[#0E7490] mt-0.5" style={{ fontVariantNumeric: "tabular-nums" }}>
              {floodData.floodAreaKm2Display}
            </p>
          </div>
        </div>

        <div className="flex items-start gap-2 text-[11px] text-[#6b7280] leading-relaxed">
          <TrendingUp className="h-3.5 w-3.5 mt-0.5 text-[#06B6D4] shrink-0" />
          <span>Based on statistical Sentinel-1 change detection (P &lt; 0.001).</span>
        </div>
      </div>
    </div>
  );
}
