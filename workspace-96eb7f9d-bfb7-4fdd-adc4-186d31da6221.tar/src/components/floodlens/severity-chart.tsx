"use client";

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { AlertTriangle } from "lucide-react";
import { floodData } from "@/lib/flood-data";

export function SeverityChart() {
  const data = floodData.severity.map((s) => ({
    name: s.label,
    value: s.percent,
    color: s.color,
  }));

  return (
    <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
      <div className="px-4 py-3 border-b border-[#e2e8e0] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-[#D97706]" />
          <h3 className="text-sm font-semibold text-[#0f172a]">Flood Impact Severity</h3>
        </div>
        <span className="text-[10px] uppercase tracking-wide text-[#9ca3af] font-medium">
          %
        </span>
      </div>

      <div className="p-4 flex flex-col sm:flex-row items-center gap-4">
        <div className="h-36 w-36 shrink-0 relative">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={36}
                outerRadius={64}
                paddingAngle={2}
                stroke="#ffffff"
                strokeWidth={2}
              >
                {data.map((entry) => (
                  <Cell key={entry.name} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  borderRadius: 8,
                  border: "1px solid #e2e8e0",
                  fontSize: 11,
                  padding: "6px 8px",
                }}
                formatter={(value: number, _name: string, entry: { payload?: { name?: string } }) => [
                  `${value}%`,
                  entry?.payload?.name ?? "",
                ]}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-center">
              <p className="text-[10px] text-[#9ca3af] uppercase">Severity</p>
              <p className="text-sm font-bold text-[#0f172a]">Mixed</p>
            </div>
          </div>
        </div>

        <div className="flex-1 w-full space-y-2">
          {floodData.severity.map((s) => (
            <div key={s.label} className="flex items-center gap-2">
              <span
                className="h-3 w-3 rounded-sm shrink-0"
                style={{ background: s.color }}
              />
              <span className="text-xs font-medium text-[#374151] flex-1">{s.label}</span>
              <span
                className="text-xs font-bold"
                style={{ color: s.color, fontVariantNumeric: "tabular-nums" }}
              >
                {s.percent}%
              </span>
            </div>
          ))}
          <p className="text-[10px] text-[#9ca3af] mt-2 leading-tight">
            Prototype impact classification
          </p>
        </div>
      </div>
    </div>
  );
}
