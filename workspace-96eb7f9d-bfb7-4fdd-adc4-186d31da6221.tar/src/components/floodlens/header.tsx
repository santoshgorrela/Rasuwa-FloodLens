"use client";

import { Activity, Calendar, Clock, Radio, Waves } from "lucide-react";
import { floodData } from "@/lib/flood-data";

export function Header() {
  return (
    <header
      className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 px-4 md:px-6 py-3 text-white"
      style={{ background: "linear-gradient(90deg, #0B4F3A 0%, #0E5C44 60%, #0B4F3A 100%)" }}
    >
      {/* Left: brand */}
      <div className="flex items-center gap-3 min-w-0">
        <div
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg"
          style={{ background: "rgba(255,255,255,0.12)" }}
        >
          <Waves className="h-5 w-5 text-cyan-300" />
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h1 className="text-lg md:text-xl font-semibold tracking-tight leading-none">
              RASUWA FLOODLENS
            </h1>
          </div>
          <p className="text-[11px] md:text-xs text-emerald-100/80 mt-1 leading-tight">
            Rapid Flood Mapping &amp; Impact Assessment
            <span className="mx-2 opacity-40">|</span>
            <span className="text-emerald-50">{floodData.location}</span>
          </p>
        </div>
      </div>

      {/* Right: status badges */}
      <div className="flex flex-wrap items-center gap-2 md:gap-3">
        <div
          className="inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium"
          style={{ background: "rgba(255,255,255,0.1)", color: "#dcfce7" }}
        >
          <Calendar className="h-3.5 w-3.5 text-cyan-300" />
          <span className="text-emerald-50/70">Event</span>
          <span className="font-semibold text-white">{floodData.eventDateDisplay}</span>
        </div>

        <div
          className="inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium"
          style={{ background: "rgba(255,255,255,0.08)", color: "#dcfce7" }}
        >
          <Clock className="h-3.5 w-3.5 text-emerald-200" />
          <span className="text-emerald-50/70">Updated</span>
          <span className="font-semibold text-white">{floodData.lastUpdatedDisplay}</span>
        </div>

        <div
          className="inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-semibold"
          style={{ background: "rgba(34, 197, 94, 0.18)", color: "#bbf7d0" }}
        >
          <span className="relative flex h-2 w-2">
            <span className="pulse-dot absolute inline-flex h-full w-full rounded-full bg-green-400" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-green-400" />
          </span>
          <Radio className="h-3.5 w-3.5 text-green-300" />
          SYSTEM ACTIVE
        </div>
      </div>
    </header>
  );
}
