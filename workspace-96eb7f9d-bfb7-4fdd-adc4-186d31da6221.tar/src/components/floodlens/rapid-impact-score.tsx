"use client";

import { Gauge } from "lucide-react";
import { floodData } from "@/lib/flood-data";
import { ModelledBadge } from "./modelled-badge";

export function RapidImpactScore() {
  const { riskScore } = floodData;
  const totalPct = Math.round((riskScore.total / riskScore.max) * 100);

  // Donut circle math
  const radius = 52;
  const stroke = 10;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (totalPct / 100) * circumference;

  const classificationColor =
    riskScore.classification === "Low"
      ? "#16A34A"
      : riskScore.classification === "Moderate"
      ? "#D97706"
      : "#DC2626";

  return (
    <div className="bg-white rounded-xl border border-[#e2e8e0] overflow-hidden shadow-sm">
      <div
        className="px-4 py-3 border-b border-[#e2e8e0] flex items-center justify-between"
        style={{ background: "linear-gradient(90deg, #0B4F3A 0%, #1B7A5A 100%)" }}
      >
        <div className="flex items-center gap-2">
          <Gauge className="h-4 w-4 text-amber-300" />
          <h3 className="text-sm font-semibold text-white">Rapid Impact Score</h3>
        </div>
        <ModelledBadge size="sm" />
      </div>

      <div className="p-4 flex flex-col sm:flex-row items-center gap-4">
        {/* Score donut */}
        <div className="relative h-32 w-32 shrink-0">
          <svg width="128" height="128" viewBox="0 0 128 128" className="-rotate-90">
            <circle
              cx="64"
              cy="64"
              r={radius}
              fill="none"
              stroke="#f1f5f3"
              strokeWidth={stroke}
            />
            <circle
              cx="64"
              cy="64"
              r={radius}
              fill="none"
              stroke={classificationColor}
              strokeWidth={stroke}
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              style={{ transition: "stroke-dashoffset 0.6s ease" }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span
              className="text-2xl font-bold leading-none"
              style={{ color: classificationColor, fontVariantNumeric: "tabular-nums" }}
            >
              {riskScore.total}
            </span>
            <span className="text-[10px] text-[#9ca3af] mt-0.5">/ {riskScore.max}</span>
          </div>
        </div>

        {/* Classification + breakdown */}
        <div className="flex-1 w-full">
          <div className="flex items-center gap-2 mb-3">
            <span
              className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide"
              style={{
                background: `${classificationColor}1a`,
                color: classificationColor,
              }}
            >
              <span
                className="h-1.5 w-1.5 rounded-full"
                style={{ background: classificationColor }}
              />
              {riskScore.classification}
            </span>
            <span className="text-[10px] text-[#9ca3af]">Prototype decision-support score</span>
          </div>

          <div className="space-y-1.5">
            {riskScore.breakdown.map((b) => {
              const pct = Math.round((b.score / b.max) * 100);
              return (
                <div key={b.label} className="space-y-0.5">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-[#374151] font-medium">{b.label}</span>
                    <span className="text-[#6b7280]" style={{ fontVariantNumeric: "tabular-nums" }}>
                      {b.score} / {b.max}
                    </span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-[#f1f5f3] overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${pct}%`, background: b.color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
