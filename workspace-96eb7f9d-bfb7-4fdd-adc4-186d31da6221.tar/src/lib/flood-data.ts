/**
 * Rasuwa FloodLens - Centralized Flood Analysis Data
 * ----------------------------------------------
 * Single source of truth for all displayed numerical values.
 *
 * Two data tiers:
 *  - DETECTED values: derived from the Google Earth Engine Sentinel-1 SAR
 *    change detection analysis run for the 26 August 2026 Rasuwa flood event.
 *  - MODELLED values: prototype decision-support estimates for infrastructure
 *    and population exposure. These are clearly labelled "Modelled estimate"
 *    throughout the UI and must NOT be described as field-confirmed.
 *
 * DO NOT scatter these numbers across components. Always import from here.
 */

export interface ModelledImpact {
  affectedRoadKm: number;
  affectedBuildings: number;
  affectedBridges: number;
  populationExposure: number;
  agricultureHa: number;
  settlementHa: number;
  infrastructureExposure: "Low" | "Moderate" | "High";
  impactLevel: "Low" | "Moderate" | "High";
}

export interface RiskScoreBreakdown {
  label: string;
  score: number;
  max: number;
  color: string;
}

export interface RiskScore {
  total: number;
  max: number;
  classification: "Low" | "Moderate" | "High";
  breakdown: RiskScoreBreakdown[];
}

export interface SeverityBreakdown {
  label: string;
  percent: number;
  color: string;
}

export interface FloodData {
  // Event metadata
  eventDate: string;
  eventDateDisplay: string;
  preDate: string;
  preDateDisplay: string;
  postDate: string;
  postDateDisplay: string;
  lastUpdated: string;
  lastUpdatedDisplay: string;

  location: string;
  region: string;

  // Satellite / acquisition metadata
  satellite: string;
  polarization: string[];
  polarizationDisplay: string;
  orbit: string;
  relativeOrbit: number;
  resolution: number;
  mode: string;
  effectiveLooks: number;
  passDirection: string;

  // Detection methodology
  significanceThreshold: number;
  significanceDisplay: string;
  detectionMethod: string;
  detectionMethodShort: string;
  confidenceWording: string;

  // Flood extent (single event in m^2, derived values in ha and km^2)
  floodAreaM2: number;
  floodAreaHa: number;
  floodAreaKm2: number;
  floodAreaM2Display: string;
  floodAreaHaDisplay: string;
  floodAreaKm2Display: string;

  // Pre-event baseline (no flood detected before the event)
  preFloodAreaKm2: number;
  preFloodAreaKm2Display: string;

  // Land cover impact (m^2)
  vegetationM2: number;
  bareLandM2: number;
  croplandM2: number;
  builtUpM2: number;
  otherM2: number;

  // Display strings for land cover
  vegetationDisplay: string;
  bareLandDisplay: string;
  croplandDisplay: string;
  builtUpDisplay: string;
  otherDisplay: string;

  // Computed percentages of total detected flood area (0-100)
  vegetationPct: number;
  bareLandPct: number;
  croplandPct: number;
  builtUpPct: number;
  otherPct: number;

  // Scene identifiers
  preSceneId: string;
  postSceneId: string;

  // AOI bounds (Rasuwa study area)
  aoi: {
    southWest: [number, number];
    northEast: [number, number];
    center: [number, number];
  };

  // Modelled impact estimates (prototype decision-support)
  modelledImpact: ModelledImpact;

  // Rapid impact score (prototype decision-support)
  riskScore: RiskScore;

  // Flood impact severity breakdown (prototype decision-support)
  severity: SeverityBreakdown[];
}

const m2 = 2544.988121032715;
const veg = 702.0932159423828;
const bare = 1140.699836730957;
const crop = 0;
const built = 0;
const other = 702.195068359375;
const total = veg + bare + crop + built + other;

const pct = (v: number) => Math.round((v / total) * 1000) / 10;

export const floodData: FloodData = {
  eventDate: "2026-08-26",
  eventDateDisplay: "26 Aug 2026",
  preDate: "2026-08-19",
  preDateDisplay: "19 Aug 2026",
  postDate: "2026-08-31",
  postDateDisplay: "31 Aug 2026",
  lastUpdated: "2026-09-30",
  lastUpdatedDisplay: "30 Sep 2026",

  location: "Rasuwa District, Nepal",
  region: "Rasuwa, Nepal",

  satellite: "Sentinel-1",
  polarization: ["VV", "VH"],
  polarizationDisplay: "VV + VH",
  orbit: "Descending",
  relativeOrbit: 121,
  resolution: 10,
  mode: "IW",
  effectiveLooks: 4.4,
  passDirection: "Descending",

  significanceThreshold: 0.001,
  significanceDisplay: "P < 0.001",
  detectionMethod: "Statistical Sentinel-1 change detection",
  detectionMethodShort: "Statistical VV + VH Change Detection",
  confidenceWording: "Statistically significant SAR change detected",

  // Original GEE export value: 2544.988121032715 m^2
  floodAreaM2: m2,
  floodAreaHa: 0.2544988121032747,
  floodAreaKm2: 0.002544988121032715,
  floodAreaM2Display: "2,544.99 m\u00B2",
  floodAreaHaDisplay: "0.2545 ha",
  floodAreaKm2Display: "0.0025 km\u00B2",

  // Pre-event baseline: no flood detected before 26 Aug 2026
  preFloodAreaKm2: 0,
  preFloodAreaKm2Display: "0.000 km\u00B2",

  // Original GEE export values (m^2)
  vegetationM2: veg,
  bareLandM2: bare,
  croplandM2: crop,
  builtUpM2: built,
  otherM2: other,

  vegetationDisplay: "702.09 m\u00B2",
  bareLandDisplay: "1,140.70 m\u00B2",
  croplandDisplay: "0 m\u00B2",
  builtUpDisplay: "0 m\u00B2",
  otherDisplay: "702.20 m\u00B2",

  // Percentages computed from the five supplied land-cover areas
  vegetationPct: pct(veg),
  bareLandPct: pct(bare),
  croplandPct: pct(crop),
  builtUpPct: pct(built),
  otherPct: pct(other),

  preSceneId: "S1D_IW_GRDH_1SDV_20260819T001036_20260819T001101_004187_007ABD_DC16",
  postSceneId: "S1D_IW_GRDH_1SDV_20260831T001037_20260831T001102_004362_0080EC_2C5B",

  // Rasuwa study AOI (lon 85.10-85.50, lat 27.90-28.38)
  aoi: {
    southWest: [27.90, 85.10],
    northEast: [28.38, 85.50],
    center: [28.14, 85.30],
  },

  // MODELLED impact estimates (prototype decision-support)
  modelledImpact: {
    affectedRoadKm: 0.42,
    affectedBuildings: 18,
    affectedBridges: 2,
    populationExposure: 74,
    agricultureHa: 0.031,
    settlementHa: 0.018,
    infrastructureExposure: "Moderate",
    impactLevel: "Moderate",
  },

  // Rapid impact score (prototype decision-support)
  // Flood extent 25/100, Infrastructure 18/25, Population 10/20, Agriculture 9/15
  riskScore: {
    total: 62,
    max: 100,
    classification: "Moderate",
    breakdown: [
      { label: "Flood extent", score: 25, max: 100, color: "#06B6D4" },
      { label: "Infrastructure", score: 18, max: 25, color: "#D97706" },
      { label: "Population", score: 10, max: 20, color: "#7C3AED" },
      { label: "Agriculture", score: 9, max: 15, color: "#16A34A" },
    ],
  },

  // Flood impact severity breakdown (prototype decision-support visualization)
  severity: [
    { label: "Low", percent: 25, color: "#22C55E" },
    { label: "Moderate", percent: 50, color: "#F59E0B" },
    { label: "High", percent: 25, color: "#EF4444" },
  ],
};

// Methodology flow steps (used in Flood Analysis + About pages)
export const methodologyFlow: { step: number; label: string; description: string; date?: string }[] = [
  { step: 1, label: "PRE-EVENT SAR", description: "Sentinel-1 IW GRDH acquisition before the flood event.", date: "19 Aug 2026" },
  { step: 2, label: "POST-EVENT SAR", description: "Sentinel-1 IW GRDH acquisition after the flood event.", date: "31 Aug 2026" },
  { step: 3, label: "VV + VH STATISTICAL COMPARISON", description: "Per-pixel statistical comparison of backscatter distributions across both polarizations." },
  { step: 4, label: "P < 0.001 SIGNIFICANT CHANGE", description: "Pixels whose change exceeds the statistical significance threshold (P < 0.001)." },
  { step: 5, label: "PERMANENT WATER MASK", description: "Removal of permanent water bodies using a reference water mask." },
  { step: 6, label: "CONNECTED-PIXEL FILTERING", description: "Morphological filtering to remove isolated noise pixels and retain coherent flood objects." },
  { step: 7, label: "FINAL FLOOD EXTENT", description: "Cleaned flood extent raster used for impact assessment and mapping." },
];

// Map layer definitions
export interface MapLayerDef {
  id: string;
  name: string;
  color: string;
  description: string;
  isPrimary?: boolean;
  isModelled?: boolean;
}

export const mapLayers: MapLayerDef[] = [
  { id: "flood-extent", name: "Final Flood Extent", color: "#06B6D4", description: "Cleaned statistically-significant flood extent", isPrimary: true },
  { id: "pre-sar", name: "Pre-event Sentinel-1", color: "#4B5563", description: "19 Aug 2026 SAR backscatter composite" },
  { id: "post-sar", name: "Post-event Sentinel-1", color: "#1F2937", description: "31 Aug 2026 SAR backscatter composite" },
  { id: "flooded-veg", name: "Flooded Vegetation", color: "#16A34A", description: "Vegetation class intersecting flood extent" },
  { id: "flooded-bare", name: "Flooded Bare / Sparse", color: "#D97706", description: "Bare/sparse land class intersecting flood extent" },
  { id: "flooded-crop", name: "Flooded Cropland", color: "#CA8A04", description: "Cropland class intersecting flood extent" },
  { id: "flooded-built", name: "Flooded Built-up", color: "#B91C1C", description: "Built-up class intersecting flood extent" },
  { id: "affected-roads", name: "Affected Roads", color: "#F97316", description: "Modelled road segments intersecting flood extent", isModelled: true },
  { id: "affected-buildings", name: "Affected Buildings", color: "#DC2626", description: "Modelled building footprints within flood extent", isModelled: true },
  { id: "affected-bridges", name: "Affected Bridges", color: "#9333EA", description: "Modelled bridge points within flood extent", isModelled: true },
  { id: "population-exposure", name: "Population Exposure", color: "#0EA5E9", description: "Modelled population exposure heatmap", isModelled: true },
];

export const legendItems = [
  { label: "Flood Extent", color: "#06B6D4" },
  { label: "Study Area", color: "#0B4F3A" },
  { label: "Affected Roads", color: "#F97316" },
  { label: "Affected Buildings", color: "#DC2626" },
  { label: "Affected Bridges", color: "#9333EA" },
  { label: "Population Exposure", color: "#0EA5E9" },
  { label: "Vegetation", color: "#16A34A" },
  { label: "Bare / Sparse", color: "#D97706" },
  { label: "Cropland", color: "#CA8A04" },
  { label: "Built-up", color: "#B91C1C" },
];

// Disclaimer shown on modelled estimate components
export const modelledEstimateTooltip =
  "Prototype estimate for decision-support demonstration. Replace with validated infrastructure datasets before operational deployment.";

export const modelledDisclaimerBanner =
  "Some impact indicators are modelled prototype estimates for demonstration and should be replaced with validated infrastructure and population datasets before operational use.";

/**
 * Earth Engine layer integration module.
 * --------------------------------------
 * The current dashboard renders an "Analysis Preview" because the live
 * Earth Engine tile endpoint is not connected in this deployment.
 *
 * When the GEE export is published (e.g. via EE's getMap() token or a
 * Cloud Run tile proxy), drop the URL template into `tileUrlTemplate`
 * and the map component will render the real flood raster automatically.
 *
 * The interface below is the only contract the map component needs.
 */
export interface EarthEngineLayerConfig {
  connected: boolean;
  label: string;
  tileUrlTemplate: string | null;
  attribution: string;
}

export const earthEngineLayer: EarthEngineLayerConfig = {
  connected: false,
  label: "Analysis Preview",
  tileUrlTemplate: null,
  attribution: "RasUwa FloodLens / Sentinel-1 SAR (preview)",
};
